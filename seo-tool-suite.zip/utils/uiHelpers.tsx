import React from 'react';

/**
 * Copies a string to the user's clipboard.
 * @param text The text to copy.
 */
export const copyToClipboard = (text: string) => {
  navigator.clipboard.writeText(text).catch(err => {
    console.error("Failed to copy text: ", err);
    // Fallback for older browsers
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
    } catch (err) {
      console.error('Fallback: Oops, unable to copy', err);
    }
    document.body.removeChild(textArea);
  });
};

/**
 * Renders a consistent loading spinner component.
 */
export const renderSpinner = () => (
  <div className="flex justify-center items-center my-8">
    <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-blue"></div>
    <p className="ml-4 text-brand-light">AI is thinking...</p>
  </div>
);

/**
 * Renders a consistent error message component.
 * @param message The error message to display.
 */
export const renderError = (message: string) => (
  <div className="my-4 p-4 bg-red-900/50 border border-red-500 text-red-300 rounded-md animate-fade-in" role="alert">
    <p className="font-bold">An error occurred</p>
    <p>{message}</p>
  </div>
);
