import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Tool, BacklinkResult, CompetitorAnalysisResult, ContentBriefResult, ContentGapResult, KeywordDensityResult, LighthouseReportResult, OnPageAnalysisResult, PaaResult, SearchIntentResult } from '../types';

// Helper to trigger download
const triggerDownload = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};

// Generate PDF from an HTML element
const generatePdf = async (elementId: string, filename: string) => {
    // Hide copy buttons during PDF generation
    const buttons = document.querySelectorAll(`#${elementId} button`);
    // FIX: Cast button element to HTMLElement to access the 'style' property.
    buttons.forEach(btn => (btn as HTMLElement).style.display = 'none');
    
    const element = document.getElementById(elementId);
    if (!element) {
        console.error('Element for PDF generation not found');
        // FIX: Cast button element to HTMLElement to access the 'style' property.
        buttons.forEach(btn => (btn as HTMLElement).style.display = ''); // Show buttons again on error
        return;
    }
    
    const canvas = await html2canvas(element, { 
        backgroundColor: '#1e293b',
        scale: 2
    });
    
    // FIX: Cast button element to HTMLElement to access the 'style' property.
    buttons.forEach(btn => (btn as HTMLElement).style.display = ''); // Show buttons again
    const data = canvas.toDataURL('image/png');

    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    let heightLeft = pdfHeight;
    let position = 0;
    const pageHeight = pdf.internal.pageSize.getHeight();

    pdf.addImage(data, 'PNG', 0, position, pdfWidth, pdfHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
        position = heightLeft - pdfHeight;
        pdf.addPage();
        pdf.addImage(data, 'PNG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pageHeight;
    }
    pdf.save(filename);
};

// Generate CSV from an array of objects
const generateCsv = (data: any[], filename: string) => {
    if (!Array.isArray(data) || data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csvRows = [
        headers.join(','),
        ...data.map(row => 
            headers.map(header => `"${String(row[header] === null || row[header] === undefined ? '' : row[header]).replace(/"/g, '""')}"`).join(',')
        )
    ];
    const csvString = csvRows.join('\r\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    triggerDownload(blob, filename);
};


// Format data based on tool type
const getFormattedData = (data: any, toolName: Tool): { txt: string, csv?: any[] } => {
    switch (toolName) {
        case Tool.META_TAGS:
            return {
                txt: `Title: ${data.title}\nDescription: ${data.description}\nKeywords: ${data.keywords.join(', ')}`,
            };
        case Tool.KEYWORD_DENSITY:
            const kdData = data as { density: KeywordDensityResult[], related: string[] };
            return {
                txt: `Keyword Density Analysis:\n\n${kdData.density.map(r => `${r.keyword}: Count ${r.count}, Density ${r.density}`).join('\n')}\n\nRelated Keywords:\n${kdData.related.join(', ')}`,
                csv: kdData.density
            };
        case Tool.COMPETITOR_RESEARCH:
            const crData = data as CompetitorAnalysisResult;
            return {
                txt: `Competitor Analysis\n\nSummary: ${crData.summary}\nDA: ${crData.domainAuthority}\nTraffic: ${crData.estimatedMonthlyTraffic}\nBacklinks: ${crData.backlinkCount}\n\nKeywords:\n- ${crData.mainKeywords.join('\n- ')}\n\nStrengths:\n- ${crData.seoStrengths.join('\n- ')}\n\nWeaknesses:\n- ${crData.seoWeaknesses.join('\n- ')}`
            };
        case Tool.BACKLINK_CHECKER:
             const bcData = data as BacklinkResult[];
            return {
                txt: `Backlinks Found:\n\n${bcData.map(l => `URL: ${l.sourceUrl}\nAnchor: ${l.anchorText}\nDA: ${l.sourceDomainAuthority}\n`).join('\n')}`,
                csv: bcData
            };
        case Tool.ON_PAGE_ANALYZER:
            const opaData = data as OnPageAnalysisResult;
            let opaTxt = 'On-Page SEO Analysis\n\n== Headings ==\n';
            opaTxt += `H1s:\n- ${opaData.headings.h1.join('\n- ')}\n`;
            opaTxt += `H2s:\n- ${opaData.headings.h2.join('\n- ')}\n`;
            opaTxt += `H3s:\n- ${opaData.headings.h3.join('\n- ')}\n\n`;
            opaTxt += `== Images ==\n${opaData.images.map(i => `src: ${i.src}, alt: ${i.alt}`).join('\n')}\n\n`;
            opaTxt += `== Internal Links ==\n${opaData.links.internal.map(l => `text: ${l.text}, href: ${l.href}`).join('\n')}\n\n`;
            opaTxt += `== External Links ==\n${opaData.links.external.map(l => `text: ${l.text}, href: ${l.href}`).join('\n')}`;
            return { txt: opaTxt };
        case Tool.LIGHTHOUSE_REPORT:
            const lhrData = data as LighthouseReportResult;
            let lhrTxt = 'Lighthouse SEO Report\n\n== SCORES ==\n';
            Object.entries(lhrData.scores).forEach(([key, value]) => {
                lhrTxt += `${key.toUpperCase()}: ${value}\n`;
            });
            Object.entries(lhrData.audits).forEach(([cat, results]) => {
                lhrTxt += `\n== ${cat.toUpperCase()} ==\n`;
                lhrTxt += `Improvements:\n${results.improvements.map(i => `- ${i.title}: ${i.description}`).join('\n')}\n`;
                lhrTxt += `Passed:\n${results.passed.map(p => `- ${p.title}`).join('\n')}\n`;
            });
            return { txt: lhrTxt };
        case Tool.CONTENT_GAP:
            const cgData = data as ContentGapResult;
            return {
                txt: `Content Gap Keywords:\n\n- ${cgData.gapKeywords.join('\n- ')}`,
                csv: cgData.gapKeywords.map(k => ({ keyword: k }))
            };
        case Tool.PAA_EXTRACTOR:
            const paaData = data as PaaResult;
            return {
                txt: `People Also Ask Questions:\n\n- ${paaData.questions.join('\n- ')}`,
                csv: paaData.questions.map(q => ({ question: q }))
            };
        case Tool.SEARCH_INTENT:
            const siData = data as SearchIntentResult[];
            return {
                txt: `Search Intent Analysis:\n\n${siData.map(i => `Keyword: ${i.keyword}\nIntent: ${i.intent}\nExplanation: ${i.explanation}\n`).join('\n')}`,
                csv: siData
            };
        case Tool.CONTENT_BRIEF:
            const cbData = data as ContentBriefResult;
            let cbTxt = `Content Brief for: ${cbData.title}\n\n`;
            cbTxt += `Target Audience: ${cbData.targetAudience}\n`;
            cbTxt += `Word Count: ${cbData.wordCount}\n\n`;
            cbTxt += `== Outline ==\n`;
            cbData.outline.forEach(item => {
                cbTxt += `- ${item.heading}\n`;
                item.subheadings.forEach(sub => { cbTxt += `  - ${sub}\n`; });
            });
            cbTxt += `\n== Related Keywords ==\n- ${cbData.relatedKeywords.join('\n- ')}\n`;
            cbTxt += `\n== Internal Link Suggestions ==\n`;
            cbData.internalLinkSuggestions.forEach(link => {
                cbTxt += `- Anchor: "${link.anchorText}", URL: ${link.suggestedUrl}\n`;
            });
            return { txt: cbTxt };
        default:
             return { txt: JSON.stringify(data, null, 2) };
    }
};

// Main export function
export const download = async (
    format: 'pdf' | 'csv' | 'txt',
    data: any,
    toolName: Tool,
    reportElementId: string
) => {
    const filenamePrefix = toolName.toLowerCase().replace(/\s+/g, '-');
    
    if (format === 'pdf') {
        await generatePdf(reportElementId, `${filenamePrefix}-report.pdf`);
        return;
    }
    
    const formatted = getFormattedData(data, toolName);
    
    if (format === 'csv') {
        if (formatted.csv) {
            generateCsv(formatted.csv, `${filenamePrefix}-data.csv`);
        } else {
            alert('CSV format is not available for this tool.');
        }
    } else if (format === 'txt') {
        const blob = new Blob([formatted.txt], { type: 'text/plain;charset=utf-8;' });
        triggerDownload(blob, `${filenamePrefix}-report.txt`);
    }
};

export const isCsvAvailable = (toolName: Tool): boolean => {
    const csvTools = [
        Tool.KEYWORD_DENSITY,
        Tool.BACKLINK_CHECKER,
        Tool.CONTENT_GAP,
        Tool.PAA_EXTRACTOR,
        Tool.SEARCH_INTENT,
    ];
    return csvTools.includes(toolName);
};
