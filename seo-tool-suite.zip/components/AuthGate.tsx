
import React from 'react';

interface AuthGateProps {
  onLoginClick: () => void;
  onSignupClick: () => void;
}

const AuthGate: React.FC<AuthGateProps> = ({ onLoginClick, onSignupClick }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
      <div className="bg-brand-dark-light p-8 rounded-lg shadow-xl max-w-lg">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4 text-brand-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
        <h2 className="text-3xl font-bold text-white mb-3">Welcome to the SEO Tool Suite</h2>
        <p className="text-brand-gray mb-6">Please log in or create an account to access the tools and save your work.</p>
        <div className="flex justify-center gap-4">
          <button
            onClick={onLoginClick}
            className="font-semibold py-2 px-6 rounded-md transition-colors text-brand-light bg-brand-dark hover:bg-brand-gray/30"
          >
            Log In
          </button>
          <button
            onClick={onSignupClick}
            className="font-semibold py-2 px-6 rounded-md transition-colors text-white bg-brand-blue hover:bg-brand-blue-light"
          >
            Sign Up
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthGate;
