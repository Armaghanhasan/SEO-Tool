

import React, { useState, useEffect } from 'react';
import { analyzeContentGap } from '../services/geminiService';
import { ContentGapResult, Tool } from '../types';
import { renderSpinner, renderError, copyToClipboard } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const ContentGapAnalysis: React.FC = () => {
  const [userUrl, setUserUrl] = useState(() => getStringState('contentGap_userUrl', ''));
  const [competitorUrl, setCompetitorUrl] = useState(() => getStringState('contentGap_competitorUrl', ''));
  const [result, setResult] = useState<ContentGapResult | null>(() => getState('contentGap_result', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const reportId = 'content-gap-report';

  useEffect(() => {
    saveStringState('contentGap_userUrl', userUrl);
  }, [userUrl]);

  useEffect(() => {
    saveStringState('contentGap_competitorUrl', competitorUrl);
  }, [competitorUrl]);

  useEffect(() => {
    saveState('contentGap_result', result);
  }, [result]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userUrl.trim() || !competitorUrl.trim()) {
      setError('Please enter both your URL and a competitor URL.');
      return;
    }
    if (!userUrl.startsWith('http') || !competitorUrl.startsWith('http')) {
        setError('Both URLs must be valid and start with http:// or https://');
        return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const apiResult = await analyzeContentGap(userUrl, competitorUrl);
      setResult(apiResult);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result?.gapKeywords) return;
    copyToClipboard(result.gapKeywords.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">Content Gap Analysis</h2>
      <p className="mb-6 text-brand-gray">Find keywords your competitors rank for, but you don't. Enter your URL and a competitor's to find content opportunities.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="url"
            value={userUrl}
            onChange={(e) => setUserUrl(e.target.value)}
            placeholder="Your URL (e.g., https://www.yoursite.com)"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Your URL"
          />
          <input
            type="url"
            value={competitorUrl}
            onChange={(e) => setCompetitorUrl(e.target.value)}
            placeholder="Competitor URL (e.g., https://www.competitor.com)"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Competitor URL"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Analyzing...' : 'Find Keyword Gaps'}
        </button>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {result && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-xl">Keyword Opportunities</h3>
                <button onClick={handleCopy} disabled={copied} className="bg-brand-gray/30 hover:bg-brand-gray/50 text-white text-sm font-bold py-2 px-4 rounded-md transition-colors disabled:opacity-50">
                {copied ? 'Copied!' : 'Copy Keywords'}
                </button>
            </div>
            {result.gapKeywords.length > 0 ? (
                <div className="flex flex-wrap gap-3">
                {result.gapKeywords.map((keyword) => (
                    <span key={keyword} className="bg-brand-blue/20 text-brand-blue-light text-sm font-medium px-3 py-1.5 rounded-full">
                    {keyword}
                    </span>
                ))}
                </div>
            ) : (
                <p className="text-brand-gray">No significant keyword gaps were found. Your content seems to align well with the competitor's!</p>
            )}
            </div>
            <DownloadControls data={result} toolName={Tool.CONTENT_GAP} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default ContentGapAnalysis;
