import React, { useState, useEffect } from 'react';
import { analyzeCompetitorUrl } from '../services/geminiService';
import { CompetitorAnalysisResult, Tool } from '../types';
import { renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const CompetitorResearch: React.FC = () => {
  const [url, setUrl] = useState(() => getStringState('competitorResearch_url', ''));
  const [analysis, setAnalysis] = useState<CompetitorAnalysisResult | null>(() => getState('competitorResearch_analysis', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const reportId = 'competitor-research-report';

  useEffect(() => {
    saveStringState('competitorResearch_url', url);
  }, [url]);

  useEffect(() => {
    saveState('competitorResearch_analysis', analysis);
  }, [analysis]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !url.startsWith('http')) {
      setError('Please enter a valid URL (e.g., https://www.example.com).');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);
    try {
      const result = await analyzeCompetitorUrl(url);
      setAnalysis(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const ResultCard = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="bg-brand-dark p-6 rounded-lg">
        <h3 className="text-xl font-semibold mb-3 text-brand-blue-light">{title}</h3>
        {children}
    </div>
  );

  const MetricCard = ({ label, value }: { label: string, value: string }) => (
    <div className="bg-brand-dark p-4 rounded-lg text-center">
        <p className="text-sm text-brand-gray uppercase tracking-wider">{label}</p>
        <p className="text-3xl font-bold text-white mt-1">{value || 'N/A'}</p>
    </div>
  );

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Competitor Research</h2>
      <p className="mb-6 text-brand-gray">Enter a competitor's URL to get an AI-generated analysis of their SEO strategy, keywords, and more.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="e.g., https://www.competitor.com"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Competitor URL for analysis"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Analyzing...' : 'Analyze URL'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {analysis && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <MetricCard label="Domain Authority" value={analysis.domainAuthority} />
                <MetricCard label="Est. Monthly Traffic" value={analysis.estimatedMonthlyTraffic} />
                <MetricCard label="Backlinks" value={analysis.backlinkCount} />
                </div>

                <ResultCard title="Executive Summary">
                    <p className="text-brand-light">{analysis.summary}</p>
                </ResultCard>

                <div className="grid md:grid-cols-2 gap-6">
                    <ResultCard title="Main Keywords">
                        <ul className="list-disc list-inside space-y-1">
                            {analysis.mainKeywords.map(kw => <li key={kw}>{kw}</li>)}
                        </ul>
                    </ResultCard>
                    <ResultCard title="Content Strategy">
                        <p className="text-brand-light">{analysis.contentStrategy}</p>
                    </ResultCard>
                    <ResultCard title="SEO Strengths">
                        <ul className="space-y-2">
                            {analysis.seoStrengths.map(strength => (
                                <li key={strength} className="flex items-start">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                    </svg>
                                    <span className="text-green-300">{strength}</span>
                                </li>
                            ))}
                        </ul>
                    </ResultCard>
                    <ResultCard title="SEO Weaknesses">
                        <ul className="space-y-2">
                            {analysis.seoWeaknesses.map(weakness => (
                                <li key={weakness} className="flex items-start">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 flex-shrink-0 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.21 3.03-1.742 3.03H4.42c-1.532 0-2.492-1.696-1.742-3.03l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                    </svg>
                                    <span className="text-yellow-300">{weakness}</span>
                                </li>
                            ))}
                        </ul>
                    </ResultCard>
                </div>
            </div>
            <DownloadControls data={analysis} toolName={Tool.COMPETITOR_RESEARCH} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default CompetitorResearch;
