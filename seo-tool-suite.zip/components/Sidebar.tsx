
import React, { useState } from 'react';
import { Tool, User } from '../types';

interface SidebarProps {
  activeTool: Tool;
  setActiveTool: (tool: Tool) => void;
  currentUser: User | null;
}

const allTools: { name: Tool, icon: JSX.Element, category: string }[] = [
  // Content & Keyword Tools
  { 
    name: Tool.META_TAGS, 
    category: 'Content',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
        <path fillRule="evenodd" d="M4 5a2 2 0 012-2h8a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h6a1 1 0 100-2H7zm0 4a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
      </svg>
    ) 
  },
  { 
    name: Tool.KEYWORD_DENSITY, 
    category: 'Content',
    icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z" />
        </svg>
    ) 
  },
  {
    name: Tool.SEARCH_INTENT,
    category: 'Content',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M5.05 3.636a1 1 0 011.414 0L10 7.172l3.536-3.536a1 1 0 111.414 1.414L11.414 8.586l3.536 3.535a1 1 0 01-1.414 1.414L10 10.414l-3.536 3.536a1 1 0 01-1.414-1.414L8.586 8.586 5.05 5.05a1 1 0 010-1.414z" clipRule="evenodd" />
      </svg>
    )
  },
  {
    name: Tool.PAA_EXTRACTOR,
    category: 'Content',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
      </svg>
    )
  },
  {
    name: Tool.CONTENT_BRIEF,
    category: 'Content',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 16c1.255 0 2.443-.29 3.5-.804V4.804zM14.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 0114.5 16c1.255 0 2.443-.29 3.5-.804v-10A7.968 7.968 0 0014.5 4z" />
      </svg>
    )
  },
  // Analysis & Research
  { 
    name: Tool.SERP_PREVIEW, 
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
      </svg>
    ) 
  },
  {
    name: Tool.ON_PAGE_ANALYZER,
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
        <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
      </svg>
    )
  },
  {
    name: Tool.LIGHTHOUSE_REPORT,
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 3.5a.75.75 0 01.75.75v.01a.75.75 0 01-.75.75A.75.75 0 019.25 4.26V4.25A.75.75 0 0110 3.5zM12.5 6.095a.75.75 0 01.53 1.28l-.001.001-.001.001a.75.75 0 01-1.06-1.061l.001-.001.531-.53zM7.5 6.095A.75.75 0 018.03 7.375l-.001.001A.75.75 0 016.97 6.314l.53-.531z"/>
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-1.5a6.5 6.5 0 110-13 6.5 6.5 0 010 13zM10 6a.75.75 0 01.75.75v3.536l2.97 1.715a.75.75 0 01-.75 1.3l-3.5-2.02a.75.75 0 01-.375-.65V6.75A.75.75 0 0110 6z" clipRule="evenodd"/>
      </svg>
    )
  },
  { 
    name: Tool.COMPETITOR_RESEARCH, 
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
      </svg>
    ) 
  },
  {
    name: Tool.CONTENT_GAP,
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
      </svg>
    )
  },
  {
    name: Tool.BACKLINK_CHECKER,
    category: 'Analysis',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
      </svg>
    )
  },
  // Generators
  { 
    name: Tool.FILE_GENERATOR, 
    category: 'Generators',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
      </svg>
    ) 
  },
];

const Sidebar: React.FC<SidebarProps> = ({ activeTool, setActiveTool, currentUser }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelectTool = (tool: Tool) => {
    setActiveTool(tool);
    setIsOpen(false);
  };
  
  const availableTools = currentUser?.role === 'admin' 
    ? allTools 
    : allTools.filter(tool => currentUser?.approvedTools?.includes(tool.name));
  
  const toolCategories = [...new Set(availableTools.map(t => t.category))];

  const SidebarContent = () => (
    <div className="bg-brand-dark-light w-64 min-h-screen flex flex-col">
      <div className="p-4 border-b border-brand-gray/20">
        <div className="flex justify-between items-center md:block text-left mb-4">
            <h1 className="text-xl font-bold text-white">SEO Tool Suite</h1>
            <button onClick={() => setIsOpen(false)} className="md:hidden text-brand-gray hover:text-white" aria-label="Close sidebar">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
            </button>
        </div>
        {currentUser && (
            <div className="flex items-center space-x-3">
                {currentUser.picture ? (
                    <img src={currentUser.picture} alt="User profile" className="h-10 w-10 rounded-full" />
                ) : (
                    <span className="h-10 w-10 rounded-full bg-brand-blue flex items-center justify-center text-white font-bold">
                        {(currentUser.name ? currentUser.name.charAt(0) : currentUser.email.charAt(0)).toUpperCase()}
                    </span>
                )}
                <div>
                    <p className="text-white font-semibold truncate">{currentUser.name || 'Welcome'}</p>
                    <p className="text-xs text-brand-gray truncate">{currentUser.email}</p>
                </div>
            </div>
        )}
      </div>
      <nav className="flex-grow p-2 overflow-y-auto">
        {currentUser?.role === 'admin' && (
             <button
                onClick={() => handleSelectTool(Tool.ADMIN_PANEL)}
                className={`flex items-center w-full text-left p-3 my-1 rounded-md transition-colors ${
                  activeTool === Tool.ADMIN_PANEL
                    ? 'bg-brand-blue text-white'
                    : 'text-brand-light hover:bg-brand-dark'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" /></svg>
                <span className="ml-3">{Tool.ADMIN_PANEL}</span>
              </button>
        )}
        {toolCategories.map(category => (
            <div key={category} className="mt-2">
                <h3 className="px-3 py-2 text-xs font-bold uppercase text-brand-gray tracking-wider">{category}</h3>
                <ul>
                {availableTools.filter(t => t.category === category).map(({ name, icon }) => (
                    <li key={name}>
                    <button
                        onClick={() => handleSelectTool(name)}
                        className={`flex items-center w-full text-left p-3 my-1 rounded-md transition-colors ${
                        activeTool === name
                            ? 'bg-brand-blue text-white'
                            : 'text-brand-light hover:bg-brand-dark'
                        }`}
                    >
                        {icon}
                        <span className="ml-3">{name}</span>
                    </button>
                    </li>
                ))}
                </ul>
            </div>
        ))}
      </nav>
    </div>
  );

  return (
    <>
      {/* --- Desktop Sidebar --- */}
      <aside className="w-64 min-h-screen flex-col hidden md:flex shrink-0">
        <SidebarContent />
      </aside>
      
      {/* --- Mobile Sidebar --- */}
      <div className="md:hidden">
        <button 
          onClick={() => setIsOpen(true)} 
          className="fixed top-4 left-4 z-30 p-2 bg-brand-dark-light rounded-md text-white"
          aria-label="Open sidebar"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        
        {/* Mobile menu content */}
        <aside 
          className={`fixed inset-y-0 left-0 z-40 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
          aria-hidden={!isOpen}
        >
            <SidebarContent />
        </aside>
        
        {/* Overlay */}
        {isOpen && (
            <div 
                className="fixed inset-0 bg-black/50 z-30" 
                onClick={() => setIsOpen(false)}
                aria-hidden="true"
            ></div>
        )}
      </div>
    </>
  );
};

export default Sidebar;
