import React, { useState, useEffect } from 'react';
import { analyzeOnPageSeo } from '../services/geminiService';
import { OnPageAnalysisResult, OnPageLink, Tool } from '../types';
import { renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const OnPageAnalyzer: React.FC = () => {
  const [url, setUrl] = useState(() => getStringState('onPageAnalyzer_url', ''));
  const [analysis, setAnalysis] = useState<OnPageAnalysisResult | null>(() => getState('onPageAnalyzer_analysis', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const reportId = 'on-page-analyzer-report';

  useEffect(() => {
    saveStringState('onPageAnalyzer_url', url);
  }, [url]);

  useEffect(() => {
    saveState('onPageAnalyzer_analysis', analysis);
  }, [analysis]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !url.startsWith('http')) {
      setError('Please enter a valid URL (e.g., https://www.example.com).');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);
    try {
      const result = await analyzeOnPageSeo(url);
      setAnalysis(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const ResultCard = ({ title, count, children }: { title: string; count: number; children: React.ReactNode }) => (
    <div className="bg-brand-dark p-6 rounded-lg">
        <h3 className="text-xl font-semibold mb-3 text-brand-blue-light">{title} <span className="text-base font-normal text-brand-gray">({count})</span></h3>
        {children}
    </div>
  );

  const renderLinksTable = (links: OnPageLink[], title: string) => (
    <ResultCard title={title} count={links.length}>
        {links.length > 0 ? (
            <div className="overflow-x-auto max-h-80">
                <table className="w-full text-left">
                    <thead>
                        <tr className="border-b border-brand-gray">
                            <th className="p-2">Anchor Text</th>
                            <th className="p-2">URL (href)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {links.map((link, index) => (
                            <tr key={index} className="border-b border-brand-gray/30">
                                <td className="p-2 text-brand-light">"{link.text}"</td>
                                <td className="p-2 max-w-sm truncate">
                                    <a href={link.href} target="_blank" rel="noopener noreferrer" className="text-brand-blue-light hover:underline" title={link.href}>
                                        {link.href}
                                    </a>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        ) : (
            <p className="text-brand-gray">No {title.toLowerCase()} found.</p>
        )}
    </ResultCard>
  );

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">On-Page SEO Analyzer</h2>
      <p className="mb-6 text-brand-gray">Enter a URL to analyze its on-page SEO elements like headings, images, and links.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="e.g., https://www.example.com/page"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="URL for on-page SEO analysis"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Analyzing...' : 'Analyze Page'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {analysis && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg space-y-6">
                
                <ResultCard title="Headings" count={analysis.headings.h1.length + analysis.headings.h2.length + analysis.headings.h3.length}>
                    <div className="space-y-4">
                        <div>
                            <h4 className="font-bold text-lg">H1 ({analysis.headings.h1.length})</h4>
                            {analysis.headings.h1.length > 0 ? (
                                <ul className="list-disc list-inside pl-2 space-y-1 mt-1 text-brand-light">
                                    {analysis.headings.h1.map((h, i) => <li key={`h1-${i}`}>{h}</li>)}
                                </ul>
                            ) : <p className="text-brand-gray italic">No H1 tags found.</p>}
                        </div>
                        <div>
                            <h4 className="font-bold text-lg">H2 ({analysis.headings.h2.length})</h4>
                            {analysis.headings.h2.length > 0 ? (
                                <ul className="list-disc list-inside pl-2 space-y-1 mt-1 text-brand-light">
                                    {analysis.headings.h2.map((h, i) => <li key={`h2-${i}`}>{h}</li>)}
                                </ul>
                            ) : <p className="text-brand-gray italic">No H2 tags found.</p>}
                        </div>
                        <div>
                            <h4 className="font-bold text-lg">H3 ({analysis.headings.h3.length})</h4>
                            {analysis.headings.h3.length > 0 ? (
                                <ul className="list-disc list-inside pl-2 space-y-1 mt-1 text-brand-light">
                                    {analysis.headings.h3.map((h, i) => <li key={`h3-${i}`}>{h}</li>)}
                                </ul>
                            ) : <p className="text-brand-gray italic">No H3 tags found.</p>}
                        </div>
                    </div>
                </ResultCard>

                <ResultCard title="Images" count={analysis.images.length}>
                    {analysis.images.length > 0 ? (
                        <div className="overflow-x-auto max-h-80">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-brand-gray">
                                        <th className="p-2">Image URL (src)</th>
                                        <th className="p-2">Alt Text</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {analysis.images.map((img, index) => (
                                        <tr key={index} className="border-b border-brand-gray/30">
                                            <td className="p-2 max-w-sm truncate">
                                                <a href={img.src} target="_blank" rel="noopener noreferrer" className="text-brand-blue-light hover:underline" title={img.src}>
                                                    {img.src}
                                                </a>
                                            </td>
                                            <td className="p-2">
                                                {img.alt && img.alt.toLowerCase() !== 'missing' ? (
                                                    <span className="text-brand-light">"{img.alt}"</span>
                                                ) : (
                                                    <span className="text-yellow-400 font-semibold">Missing</span>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <p className="text-brand-gray">No images found.</p>
                    )}
                </ResultCard>

                <div className="grid md:grid-cols-2 gap-6">
                    {renderLinksTable(analysis.links.internal, 'Internal Links')}
                    {renderLinksTable(analysis.links.external, 'External Links')}
                </div>
            </div>
            <DownloadControls data={analysis} toolName={Tool.ON_PAGE_ANALYZER} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default OnPageAnalyzer;
