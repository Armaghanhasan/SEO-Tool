
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '../types';
import EditUserModal from './EditUserModal';
import { getAllUsers, updateUser, deleteUser } from '../services/databaseService';

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const refreshUsers = useCallback(() => {
    setUsers(getAllUsers());
  }, []);

  useEffect(() => {
    refreshUsers();
  }, [refreshUsers]);

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const handleDelete = (email: string) => {
    if (window.confirm(`Are you sure you want to delete the user ${email}? This action cannot be undone.`)) {
      deleteUser(email);
      refreshUsers();
    }
  };
  
  const handleToggleApproval = (user: User) => {
    const updatedUser = { ...user, isApproved: !user.isApproved };
    updateUser(updatedUser);
    refreshUsers();
  };

  const handleSaveChanges = (updatedUser: User) => {
    updateUser(updatedUser);
    setIsModalOpen(false);
    setEditingUser(null);
    refreshUsers();
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">Admin Panel</h2>
      <p className="mb-6 text-brand-gray">Manage users and their permissions.</p>

      <div className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
        <h3 className="font-semibold text-xl mb-4">User Management</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-brand-gray">
                <th className="p-3">Email</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.email} className="border-b border-brand-gray/30">
                  <td className="p-3 font-medium text-brand-light">{user.email}{user.role === 'admin' && <span className="ml-2 text-xs text-amber-400">(Admin)</span>}</td>
                  <td className="p-3 text-center">
                    <button 
                        onClick={() => user.role !== 'admin' && handleToggleApproval(user)}
                        disabled={user.role === 'admin'}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-full ${user.isApproved ? 'bg-emerald-800 text-emerald-300' : 'bg-amber-800 text-amber-300'} ${user.role !== 'admin' ? 'cursor-pointer hover:opacity-80' : 'cursor-not-allowed'}`}
                    >
                        {user.isApproved ? 'Approved' : 'Pending'}
                    </button>
                  </td>
                  <td className="p-3 text-center space-x-2">
                    <button
                      onClick={() => handleEdit(user)}
                      className="text-brand-blue-light hover:underline text-sm"
                    >
                      Permissions
                    </button>
                    {user.role !== 'admin' && (
                        <>
                            <span className="text-brand-gray">|</span>
                            <button
                                onClick={() => handleDelete(user.email)}
                                className="text-red-400 hover:underline text-sm"
                            >
                                Delete
                            </button>
                        </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {isModalOpen && editingUser && (
        <EditUserModal 
            user={editingUser}
            onClose={() => setIsModalOpen(false)}
            onSave={handleSaveChanges}
        />
      )}
    </div>
  );
};

export default AdminPanel;
