
import React, { useState } from 'react';
import { User, Tool } from '../types';

interface EditUserModalProps {
  user: User;
  onClose: () => void;
  onSave: (user: User) => void;
}

const EditUserModal: React.FC<EditUserModalProps> = ({ user, onClose, onSave }) => {
  const [isApproved, setIsApproved] = useState(user.isApproved);
  const [approvedTools, setApprovedTools] = useState<Tool[]>(user.approvedTools || []);

  const allTools = Object.values(Tool).filter(t => t !== Tool.ADMIN_PANEL);

  const handleToolToggle = (tool: Tool) => {
    setApprovedTools(prev => 
      prev.includes(tool) ? prev.filter(t => t !== tool) : [...prev, tool]
    );
  };

  const handleSave = () => {
    onSave({ ...user, isApproved, approvedTools });
  };
  
  const isAdmin = user.role === 'admin';

  return (
    <div 
      className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in" 
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-brand-dark-light rounded-lg shadow-xl w-full max-w-lg m-4 p-8 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-brand-gray hover:text-white"
          aria-label="Close modal"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="text-2xl font-bold text-white mb-1">Edit Permissions</h2>
        <p className="text-brand-gray mb-6 truncate">{user.email}</p>

        <div className="space-y-6">
            <div>
                <h3 className="font-semibold mb-2 text-lg">Account Status</h3>
                <label className="flex items-center space-x-3 cursor-pointer">
                    <input 
                        type="checkbox" 
                        checked={isApproved}
                        onChange={() => setIsApproved(!isApproved)}
                        disabled={isAdmin}
                        className="h-5 w-5 rounded text-brand-blue bg-brand-dark border-brand-gray focus:ring-brand-blue disabled:opacity-50" 
                    />
                    <span className="text-brand-light">
                        Account is Approved
                        {isAdmin && <span className="text-xs text-amber-400 ml-2">(Admin cannot be unapproved)</span>}
                    </span>
                </label>
            </div>
            
            <div>
                <h3 className="font-semibold mb-2 text-lg">Tool Access</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto pr-2">
                    {allTools.map(tool => (
                        <label key={tool} className="flex items-center space-x-3 cursor-pointer bg-brand-dark p-2 rounded-md">
                           <input 
                                type="checkbox" 
                                checked={approvedTools.includes(tool)}
                                onChange={() => handleToolToggle(tool)}
                                disabled={isAdmin}
                                className="h-4 w-4 rounded text-brand-blue bg-brand-dark border-brand-gray focus:ring-brand-blue disabled:opacity-50" 
                            />
                            <span className="text-sm text-brand-light">{tool}</span>
                        </label>
                    ))}
                     {isAdmin && <p className="text-xs text-amber-400 col-span-full mt-2">Admins have access to all tools by default.</p>}
                </div>
            </div>
        </div>

        <div className="flex justify-end gap-4 mt-8">
            <button onClick={onClose} className="font-semibold py-2 px-5 rounded-md transition-colors text-brand-light bg-brand-dark hover:bg-brand-gray/30">
                Cancel
            </button>
            <button onClick={handleSave} className="font-semibold py-2 px-5 rounded-md transition-colors text-white bg-brand-blue hover:bg-brand-blue-light">
                Save Changes
            </button>
        </div>
      </div>
    </div>
  );
};

export default EditUserModal;
