
import React from 'react';

const PendingApproval: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
      <div className="bg-brand-dark-light p-8 rounded-lg shadow-xl max-w-lg">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h2 className="text-3xl font-bold text-white mb-3">Account Pending Approval</h2>
        <p className="text-brand-gray mb-6">
          Thank you for signing up! Your account is currently awaiting approval from an administrator.
          You will have access to the tools once your account has been reviewed and approved.
        </p>
      </div>
    </div>
  );
};

export default PendingApproval;
