

import React, { useState, useEffect } from 'react';
import { extractPeopleAlsoAsk } from '../services/geminiService';
import { PaaResult, Tool } from '../types';
import { renderSpinner, renderError, copyToClipboard } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const PaaExtractor: React.FC = () => {
  const [topic, setTopic] = useState(() => getStringState('paaExtractor_topic', ''));
  const [result, setResult] = useState<PaaResult | null>(() => getState('paaExtractor_result', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const reportId = 'paa-extractor-report';

  useEffect(() => {
    saveStringState('paaExtractor_topic', topic);
  }, [topic]);

  useEffect(() => {
    saveState('paaExtractor_result', result);
  }, [result]);

  const handleExtract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter a topic to find questions.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const apiResult = await extractPeopleAlsoAsk(topic);
      setResult(apiResult);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result?.questions) return;
    copyToClipboard(result.questions.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">People Also Ask (PAA) Extractor</h2>
      <p className="mb-6 text-brand-gray">Discover what questions users are asking on Google. Enter a topic to get a list of questions for your FAQ or content ideas.</p>
      
      <form onSubmit={handleExtract} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., 'Core Web Vitals'"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Topic for PAA extraction"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Extracting...' : 'Find Questions'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {result && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-xl">Questions Found</h3>
                <button onClick={handleCopy} disabled={copied} className="bg-brand-gray/30 hover:bg-brand-gray/50 text-white text-sm font-bold py-2 px-4 rounded-md transition-colors disabled:opacity-50">
                {copied ? 'Copied!' : 'Copy Questions'}
                </button>
            </div>
            {result.questions.length > 0 ? (
                <ul className="space-y-3">
                {result.questions.map((q, index) => (
                    <li key={index} className="flex items-start p-3 bg-brand-dark rounded-md">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 flex-shrink-0 text-brand-blue-light mt-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                    <span className="text-brand-light">{q}</span>
                    </li>
                ))}
                </ul>
            ) : (
                <p className="text-brand-gray">No "People Also Ask" questions were found for this topic.</p>
            )}
            </div>
            <DownloadControls data={result} toolName={Tool.PAA_EXTRACTOR} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default PaaExtractor;
