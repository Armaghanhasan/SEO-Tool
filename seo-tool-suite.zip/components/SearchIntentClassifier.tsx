

import React, { useState, useEffect } from 'react';
import { classifySearchIntent } from '../services/geminiService';
import { SearchIntentResult, Tool } from '../types';
import { renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const SearchIntentClassifier: React.FC = () => {
  const [keywords, setKeywords] = useState(() => getStringState('searchIntent_keywords', ''));
  const [results, setResults] = useState<SearchIntentResult[] | null>(() => getState('searchIntent_results', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const reportId = 'search-intent-report';

  useEffect(() => {
    saveStringState('searchIntent_keywords', keywords);
  }, [keywords]);

  useEffect(() => {
    saveState('searchIntent_results', results);
  }, [results]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    const keywordList = keywords.split('\n').filter(k => k.trim() !== '');
    if (keywordList.length === 0) {
      setError('Please enter at least one keyword.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResults(null);
    try {
      const apiResult = await classifySearchIntent(keywordList);
      setResults(apiResult);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const getIntentBadgeColor = (intent: string) => {
    switch (intent.toLowerCase()) {
      case 'informational': return 'bg-sky-800 text-sky-300';
      case 'navigational': return 'bg-indigo-800 text-indigo-300';
      case 'commercial': return 'bg-amber-800 text-amber-300';
      case 'transactional': return 'bg-emerald-800 text-emerald-300';
      default: return 'bg-gray-700 text-gray-300';
    }
  }

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">Search Intent Classifier</h2>
      <p className="mb-6 text-brand-gray">Understand user intent behind keywords. Enter a list of keywords (one per line) to classify them.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <textarea
          value={keywords}
          onChange={(e) => setKeywords(e.target.value)}
          placeholder="best running shoes&#10;how to tie a tie&#10;facebook login"
          rows={6}
          className="w-full p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
          aria-label="Keywords for intent classification"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="mt-4 bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Classifying...' : 'Classify Keywords'}
        </button>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {results && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
            <h3 className="font-semibold text-xl mb-4">Intent Analysis</h3>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                <thead>
                    <tr className="border-b border-brand-gray">
                    <th className="p-3">Keyword</th>
                    <th className="p-3">Intent</th>
                    <th className="p-3">Explanation</th>
                    </tr>
                </thead>
                <tbody>
                    {results.map((result) => (
                    <tr key={result.keyword} className="border-b border-brand-gray/30">
                        <td className="p-3 font-medium text-brand-light">{result.keyword}</td>
                        <td className="p-3">
                        <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${getIntentBadgeColor(result.intent)}`}>
                            {result.intent}
                        </span>
                        </td>
                        <td className="p-3 text-brand-gray">{result.explanation}</td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>
            </div>
            <DownloadControls data={results} toolName={Tool.SEARCH_INTENT} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default SearchIntentClassifier;
