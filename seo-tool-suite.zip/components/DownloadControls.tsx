import React, { useState } from 'react';
import { download, isCsvAvailable } from '../utils/downloadService';
import { Tool } from '../types';

interface DownloadControlsProps {
  data: any;
  toolName: Tool;
  reportElementId: string;
}

const DownloadControls: React.FC<DownloadControlsProps> = ({ data, toolName, reportElementId }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isDownloading, setIsDownloading] = useState<string | null>(null);

  const handleDownload = async (format: 'pdf' | 'csv' | 'txt') => {
    if (isDownloading) return; 
    
    setIsDownloading(format);
    setIsOpen(false);
    try {
        await download(format, data, toolName, reportElementId);
    } catch (error) {
        console.error(`Failed to download as ${format}:`, error);
        alert(`Sorry, there was an error creating the ${format.toUpperCase()} file.`);
    } finally {
        setIsDownloading(null);
    }
  };

  const csvEnabled = isCsvAvailable(toolName);

  return (
    <div className="relative inline-block text-left mt-4">
      <div>
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          disabled={!!isDownloading}
          className="inline-flex justify-center w-full rounded-md border border-brand-gray shadow-sm px-4 py-2 bg-brand-dark-light text-sm font-medium text-white hover:bg-brand-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-dark-light focus:ring-brand-blue disabled:opacity-50"
        >
          {isDownloading ? `Downloading ${isDownloading.toUpperCase()}...` : 'Download Results'}
          <svg className={`-mr-1 ml-2 h-5 w-5 ${isDownloading ? 'animate-spin' : ''}`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>

      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-brand-dark-light ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
          <div className="py-1" role="menu" aria-orientation="vertical">
            <a href="#" onClick={(e) => { e.preventDefault(); handleDownload('pdf'); }} className="text-brand-light block px-4 py-2 text-sm hover:bg-brand-dark" role="menuitem">Download as PDF</a>
            <a href="#" onClick={(e) => { e.preventDefault(); handleDownload('txt'); }} className="text-brand-light block px-4 py-2 text-sm hover:bg-brand-dark" role="menuitem">Download as TXT</a>
            {csvEnabled && (
                <a href="#" onClick={(e) => { e.preventDefault(); handleDownload('csv'); }} className="text-brand-light block px-4 py-2 text-sm hover:bg-brand-dark" role="menuitem">Download as CSV</a>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default DownloadControls;
