
import React from 'react';
import { User } from '../types';

interface AuthControlsProps {
  currentUser: User | null;
  onLoginClick: () => void;
  onSignupClick: () => void;
  onLogoutClick: () => void;
}

const AuthControls: React.FC<AuthControlsProps> = ({ currentUser, onLoginClick, onSignupClick, onLogoutClick }) => {
  return (
    <div className="absolute top-4 right-6 md:top-8 md:right-10 z-10 flex items-center gap-2 md:gap-4">
      {currentUser ? (
        <>
          <span className="text-brand-gray text-sm hidden sm:inline" title={currentUser.email}>
            Welcome, {currentUser.name ? currentUser.name.split(' ')[0] : currentUser.email}
          </span>
          <button
            onClick={onLogoutClick}
            className="font-semibold py-2 px-4 rounded-md transition-colors text-brand-light bg-brand-dark-light hover:bg-brand-gray/30 text-sm"
          >
            Log Out
          </button>
        </>
      ) : (
        <>
          <button
            onClick={onLoginClick}
            className="font-semibold py-2 px-4 rounded-md transition-colors text-brand-light hover:bg-brand-dark-light text-sm"
          >
            Log In
          </button>
          <button
            onClick={onSignupClick}
            className="font-semibold py-2 px-4 rounded-md transition-colors text-white bg-brand-blue hover:bg-brand-blue-light text-sm"
          >
            Sign Up
          </button>
        </>
      )}
    </div>
  );
};

export default AuthControls;