import React, { useState, useEffect } from 'react';
import { generateMetaTags } from '../services/geminiService';
import { copyToClipboard, renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { Tool } from '../types';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

interface MetaTags {
  title: string;
  description: string;
  keywords: string[];
}

const MetaTagGenerator: React.FC = () => {
  const [topic, setTopic] = useState(() => getStringState('metaTagGenerator_topic', ''));
  const [metaTags, setMetaTags] = useState<MetaTags | null>(() => getState('metaTagGenerator_metaTags', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const reportId = 'meta-tags-report';

  useEffect(() => {
    saveStringState('metaTagGenerator_topic', topic);
  }, [topic]);

  useEffect(() => {
    saveState('metaTagGenerator_metaTags', metaTags);
  }, [metaTags]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter a topic.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setMetaTags(null);
    try {
      const result = await generateMetaTags(topic);
      setMetaTags(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, key: string) => {
    copyToClipboard(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };
  
  const copyAll = () => {
    if (!metaTags) return;
    const allTags = `
<title>${metaTags.title}</title>
<meta name="description" content="${metaTags.description}">
<meta name="keywords" content="${metaTags.keywords.join(', ')}">
    `.trim();
    handleCopy(allTags, 'all');
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Meta Tag Generator</h2>
      <p className="mb-6 text-brand-gray">Enter a topic or keyword, and our AI will generate SEO-optimized title tags, meta descriptions, and keywords for your webpage.</p>
      
      <form onSubmit={handleGenerate} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., 'Best practices for React development'"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Topic for meta tag generation"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Generating...' : 'Generate Tags'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {metaTags && (
        <div className="animate-fade-in">
          <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
              <div className="mb-6">
                  <h3 className="font-semibold mb-2 text-lg">Title Tag</h3>
                  <div className="relative p-4 bg-brand-dark rounded-md">
                      <p className="text-brand-light pr-12">{metaTags.title}</p>
                      <button 
                          onClick={() => handleCopy(metaTags.title, 'title')} 
                          disabled={copied === 'title'}
                          className={`absolute top-1/2 right-3 -translate-y-1/2 p-1 rounded-md transition-colors font-semibold ${copied === 'title' ? 'text-green-400' : 'text-brand-gray hover:text-white'}`}
                      >
                          {copied === 'title' ? 'Copied!' : 'Copy'}
                      </button>
                  </div>
              </div>

              <div className="mb-6">
                  <h3 className="font-semibold mb-2 text-lg">Meta Description</h3>
                  <div className="relative p-4 bg-brand-dark rounded-md">
                      <p className="text-brand-light pr-12">{metaTags.description}</p>
                      <button 
                          onClick={() => handleCopy(metaTags.description, 'desc')} 
                          disabled={copied === 'desc'}
                          className={`absolute top-1/2 right-3 -translate-y-1/2 p-1 rounded-md transition-colors font-semibold ${copied === 'desc' ? 'text-green-400' : 'text-brand-gray hover:text-white'}`}
                      >
                          {copied === 'desc' ? 'Copied!' : 'Copy'}
                      </button>
                  </div>
              </div>

              <div className="mb-6">
                  <h3 className="font-semibold mb-2 text-lg">Meta Keywords</h3>
                  <div className="relative p-4 bg-brand-dark rounded-md">
                      <p className="text-brand-light pr-12">{metaTags.keywords.join(', ')}</p>
                      <button 
                          onClick={() => handleCopy(metaTags.keywords.join(', '), 'keywords')} 
                          disabled={copied === 'keywords'}
                          className={`absolute top-1/2 right-3 -translate-y-1/2 p-1 rounded-md transition-colors font-semibold ${copied === 'keywords' ? 'text-green-400' : 'text-brand-gray hover:text-white'}`}
                      >
                          {copied === 'keywords' ? 'Copied!' : 'Copy'}
                      </button>
                  </div>
              </div>
              
              <button
                  onClick={copyAll}
                  disabled={copied === 'all'}
                  className={`w-full text-white font-bold py-3 px-6 rounded-md transition-colors disabled:cursor-not-allowed ${copied === 'all' ? 'bg-green-800' : 'bg-green-600 hover:bg-green-700'}`}
              >
                  {copied === 'all' ? 'Copied!' : 'Copy All Tags as HTML'}
              </button>
          </div>
          <DownloadControls data={metaTags} toolName={Tool.META_TAGS} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default MetaTagGenerator;
