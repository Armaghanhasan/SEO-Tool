import React, { useState, useEffect } from 'react';
import { findBacklinks } from '../services/geminiService';
import { BacklinkResult, Tool } from '../types';
import { renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const BacklinkChecker: React.FC = () => {
  const [domain, setDomain] = useState(() => getStringState('backlinkChecker_domain', ''));
  const [backlinks, setBacklinks] = useState<BacklinkResult[] | null>(() => getState('backlinkChecker_backlinks', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const reportId = 'backlink-checker-report';

  useEffect(() => {
    saveStringState('backlinkChecker_domain', domain);
  }, [domain]);

  useEffect(() => {
    saveState('backlinkChecker_backlinks', backlinks);
  }, [backlinks]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain.trim()) {
      setError('Please enter a valid domain (e.g., example.com).');
      return;
    }
    setIsLoading(true);
    setError(null);
    setBacklinks(null);
    try {
      const result = await findBacklinks(domain);
      setBacklinks(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Backlink Checker</h2>
      <p className="mb-6 text-brand-gray">Enter a domain to find its top backlinks, powered by AI and Google Search.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            placeholder="e.g., tailwindcss.com"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Domain for backlink analysis"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Searching...' : 'Find Backlinks'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {backlinks && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
                <h3 className="font-semibold text-xl mb-4">Top Backlinks Found</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b border-brand-gray">
                                <th className="p-3">Source URL</th>
                                <th className="p-3">Anchor Text</th>
                                <th className="p-3 text-center">Source DA</th>
                            </tr>
                        </thead>
                        <tbody>
                            {backlinks.map((link, index) => (
                                <tr key={index} className="border-b border-brand-gray/30">
                                    <td className="p-3 font-medium max-w-sm truncate">
                                        <a href={link.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-brand-blue-light hover:underline" title={link.sourceUrl}>
                                            {link.sourceUrl}
                                        </a>
                                    </td>
                                    <td className="p-3 text-brand-light italic">"{link.anchorText}"</td>
                                    <td className="p-3 text-center font-bold text-lg">{link.sourceDomainAuthority}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <DownloadControls data={backlinks} toolName={Tool.BACKLINK_CHECKER} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default BacklinkChecker;
