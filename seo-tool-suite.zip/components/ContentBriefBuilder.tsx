

import React, { useState, useEffect } from 'react';
import { generateContentBrief } from '../services/geminiService';
import { ContentBriefResult, Tool } from '../types';
import { renderSpinner, renderError, copyToClipboard } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const ContentBriefBuilder: React.FC = () => {
  const [topic, setTopic] = useState(() => getStringState('contentBriefBuilder_topic', ''));
  const [brief, setBrief] = useState<ContentBriefResult | null>(() => getState('contentBriefBuilder_brief', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const reportId = 'content-brief-report';

  useEffect(() => {
    saveStringState('contentBriefBuilder_topic', topic);
  }, [topic]);

  useEffect(() => {
    saveState('contentBriefBuilder_brief', brief);
  }, [brief]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) {
      setError('Please enter a topic to generate a brief.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setBrief(null);
    try {
      const result = await generateContentBrief(topic);
      setBrief(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCopyBrief = () => {
    if (!brief) return;
    let briefText = `Content Brief for: ${topic}\n\n`;
    briefText += `Title: ${brief.title}\n`;
    briefText += `Target Audience: ${brief.targetAudience}\n`;
    briefText += `Word Count: ${brief.wordCount}\n\n`;
    briefText += `== Outline ==\n`;
    brief.outline.forEach(item => {
        briefText += `- ${item.heading}\n`;
        item.subheadings.forEach(sub => {
            briefText += `  - ${sub}\n`;
        });
    });
    briefText += `\n== Related Keywords ==\n- ${brief.relatedKeywords.join('\n- ')}\n`;
    briefText += `\n== Internal Link Suggestions ==\n`;
    brief.internalLinkSuggestions.forEach(link => {
        briefText += `- Anchor: "${link.anchorText}", URL: ${link.suggestedUrl}\n`;
    });

    copyToClipboard(briefText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const ResultCard = ({ title, children, className = "" }: { title: string, children: React.ReactNode, className?: string }) => (
    <div className={`bg-brand-dark p-6 rounded-lg ${className}`}>
        <h3 className="text-xl font-semibold mb-3 text-brand-blue-light">{title}</h3>
        {children}
    </div>
  );

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Content Brief Builder</h2>
      <p className="mb-6 text-brand-gray">Generate a comprehensive SEO content brief for any topic to streamline your content creation process.</p>
      
      <form onSubmit={handleGenerate} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., 'The Future of Renewable Energy'"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="Topic for content brief"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Building...' : 'Build Brief'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {brief && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg space-y-6">
                <div className="flex justify-between items-center">
                    <h3 className="text-2xl font-bold">Content Brief: {topic}</h3>
                    <button onClick={handleCopyBrief} disabled={copied} className="bg-brand-gray/30 hover:bg-brand-gray/50 text-white text-sm font-bold py-2 px-4 rounded-md transition-colors disabled:opacity-50">
                        {copied ? 'Copied!' : 'Copy Brief Text'}
                    </button>
                </div>
                
                <ResultCard title="Suggested Title">
                    <p className="text-lg italic text-brand-light">{brief.title}</p>
                </ResultCard>

                <div className="grid md:grid-cols-2 gap-6">
                    <ResultCard title="Target Audience">
                        <p className="text-brand-light">{brief.targetAudience}</p>
                    </ResultCard>
                    <ResultCard title="Suggested Word Count">
                        <p className="text-brand-light text-2xl font-bold">{brief.wordCount}</p>
                    </ResultCard>
                </div>

                <ResultCard title="Content Outline">
                    <ul className="space-y-3">
                        {brief.outline.map((item, index) => (
                            <li key={index}>
                                <p className="font-bold text-white">{item.heading}</p>
                                {item.subheadings.length > 0 && (
                                    <ul className="list-disc list-inside pl-4 mt-1 space-y-1 text-brand-light">
                                        {item.subheadings.map((sub, subIndex) => <li key={subIndex}>{sub}</li>)}
                                    </ul>
                                )}
                            </li>
                        ))}
                    </ul>
                </ResultCard>

                <ResultCard title="Related & LSI Keywords">
                    <div className="flex flex-wrap gap-3">
                        {brief.relatedKeywords.map((keyword) => (
                            <span key={keyword} className="bg-brand-blue/20 text-brand-blue-light text-sm font-medium px-3 py-1.5 rounded-full">
                                {keyword}
                            </span>
                        ))}
                    </div>
                </ResultCard>
                
                <ResultCard title="Internal Link Suggestions">
                    <ul className="space-y-2">
                        {brief.internalLinkSuggestions.map((link, index) => (
                            <li key={index} className="text-brand-light">
                                Anchor Text: <span className="font-semibold italic">"{link.anchorText}"</span> <br/>
                                Suggested URL: <code className="text-brand-blue-light">{link.suggestedUrl}</code>
                            </li>
                        ))}
                    </ul>
                </ResultCard>
            </div>
            <DownloadControls data={brief} toolName={Tool.CONTENT_BRIEF} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default ContentBriefBuilder;
