

import React, { useState, useEffect } from 'react';
import { generateLighthouseReport } from '../services/geminiService';
import { LighthouseReportResult, LighthouseAuditItem, Tool } from '../types';
import { renderSpinner, renderError } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

// Sub-component for the score circle
const ScoreCircle: React.FC<{ score: number; title: string }> = ({ score, title }) => {
  const getScoreColor = (s: number) => {
    if (s >= 90) return 'text-green-400';
    if (s >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  const color = getScoreColor(score);
  const circumference = 2 * Math.PI * 45; // r = 45
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle
            className="text-brand-dark"
            strokeWidth="10"
            stroke="currentColor"
            fill="transparent"
            r="45"
            cx="50"
            cy="50"
          />
          {/* Progress circle */}
          <circle
            className={color}
            strokeWidth="10"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            stroke="currentColor"
            fill="transparent"
            r="45"
            cx="50"
            cy="50"
            style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}
          />
        </svg>
        <div className={`absolute inset-0 flex items-center justify-center text-3xl font-bold ${color}`}>
          {score}
        </div>
      </div>
      <p className="mt-2 text-lg font-semibold text-brand-light capitalize">{title}</p>
    </div>
  );
};


const AuditList: React.FC<{ items: LighthouseAuditItem[]; type: 'passed' | 'improvement' }> = ({ items, type }) => {
    const isPassed = type === 'passed';
    const icon = isPassed ? (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 flex-shrink-0 text-green-400" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
      </svg>
    ) : (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 flex-shrink-0 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.21 3.03-1.742 3.03H4.42c-1.532 0-2.492-1.696-1.742-3.03l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
      </svg>
    );
    
    if (items.length === 0) return null;

    return (
      <div className="bg-brand-dark p-4 rounded-lg mb-4">
        <h3 className={`text-lg font-semibold mb-3 ${isPassed ? 'text-green-300' : 'text-yellow-300'}`}>
          {isPassed ? 'Passed Audits' : 'Areas for Improvement'}
        </h3>
        <ul className="space-y-4">
          {items.map((item) => (
            <li key={item.title} className="flex items-start">
              {icon}
              <div>
                <h4 className="font-semibold text-brand-light">{item.title}</h4>
                <p className="text-brand-gray text-sm">{item.description}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    );
};

const AccordionItem: React.FC<{ title: string; isOpen: boolean; onToggle: () => void; children: React.ReactNode }> = ({ title, isOpen, onToggle, children }) => {
    return (
        <div className="bg-brand-dark-light rounded-lg overflow-hidden">
            <button
                onClick={onToggle}
                className="w-full flex justify-between items-center p-4 text-left font-semibold text-xl text-white hover:bg-brand-dark transition-colors"
                aria-expanded={isOpen}
            >
                <span className="capitalize">{title}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 transform transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            {isOpen && (
                <div className="p-4 border-t border-brand-gray/20 animate-fade-in">
                    {children}
                </div>
            )}
        </div>
    );
};


// Main component
const LighthouseReport: React.FC = () => {
  const [url, setUrl] = useState(() => getStringState('lighthouseReport_url', ''));
  const [report, setReport] = useState<LighthouseReportResult | null>(() => getState('lighthouseReport_report', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openAccordion, setOpenAccordion] = useState<string | null>('performance');
  const reportId = 'lighthouse-report-container';

  useEffect(() => {
    saveStringState('lighthouseReport_url', url);
  }, [url]);

  useEffect(() => {
    saveState('lighthouseReport_report', report);
  }, [report]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !url.startsWith('http')) {
      setError('Please enter a valid URL (e.g., https://www.example.com).');
      return;
    }
    setIsLoading(true);
    setError(null);
    setReport(null);
    setOpenAccordion('performance');
    try {
      const result = await generateLighthouseReport(url);
      setReport(result);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleToggleAccordion = (key: string) => {
    setOpenAccordion(openAccordion === key ? null : key);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Lighthouse SEO Report</h2>
      <p className="mb-6 text-brand-gray">Get a detailed, GTmetrix-style SEO report for any URL, generated by AI.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="e.g., https://www.example.com/page"
            className="flex-grow p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            aria-label="URL for Lighthouse SEO report"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Generating Report...' : 'Analyze'}
          </button>
        </div>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {report && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg space-y-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(report.scores).map(([key, value]) => (
                        <ScoreCircle key={key} score={value} title={key} />
                    ))}
                </div>
                
                <div className="space-y-2">
                    {Object.entries(report.audits).map(([key, value]) => (
                        <AccordionItem
                            key={key}
                            title={key}
                            isOpen={openAccordion === key}
                            onToggle={() => handleToggleAccordion(key)}
                        >
                            <AuditList items={value.improvements} type="improvement" />
                            <AuditList items={value.passed} type="passed" />
                        </AccordionItem>
                    ))}
                </div>
            </div>
            <DownloadControls data={report} toolName={Tool.LIGHTHOUSE_REPORT} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default LighthouseReport;
