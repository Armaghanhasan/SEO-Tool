import React, { useState, useEffect } from 'react';
import { generateRobotsTxt, generateSitemap } from '../services/geminiService';
import { copyToClipboard, renderSpinner, renderError } from '../utils/uiHelpers';
import { getStringState, saveStringState } from '../services/toolStateService';

type GeneratorType = 'robots' | 'sitemap';

const FileGenerator: React.FC = () => {
  const [activeGenerator, setActiveGenerator] = useState<GeneratorType>(
    () => (getStringState('fileGenerator_activeGenerator', 'robots') as GeneratorType)
  );
  const [robotsInstruction, setRobotsInstruction] = useState(
    () => getStringState('fileGenerator_robotsInstruction', '')
  );
  const [sitemapUrls, setSitemapUrls] = useState(
    () => getStringState('fileGenerator_sitemapUrls', '')
  );
  const [robotsResult, setRobotsResult] = useState(() => getStringState('fileGenerator_robotsResult', ''));
  const [sitemapResult, setSitemapResult] = useState(() => getStringState('fileGenerator_sitemapResult', ''));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => { saveStringState('fileGenerator_activeGenerator', activeGenerator); }, [activeGenerator]);
  useEffect(() => { saveStringState('fileGenerator_robotsInstruction', robotsInstruction); }, [robotsInstruction]);
  useEffect(() => { saveStringState('fileGenerator_sitemapUrls', sitemapUrls); }, [sitemapUrls]);
  useEffect(() => { saveStringState('fileGenerator_robotsResult', robotsResult); }, [robotsResult]);
  useEffect(() => { saveStringState('fileGenerator_sitemapResult', sitemapResult); }, [sitemapResult]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setCopied(false);

    try {
      if (activeGenerator === 'robots') {
        if (!robotsInstruction.trim()) throw new Error('Please provide instructions for the robots.txt file.');
        const content = await generateRobotsTxt({ instruction: robotsInstruction });
        setRobotsResult(content);
      } else {
        const urls = sitemapUrls.split('\n').filter(url => url.trim() !== '');
        if (urls.length === 0) throw new Error('Please provide at least one URL for the sitemap.');
        const content = await generateSitemap(urls);
        setSitemapResult(content);
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const currentResult = activeGenerator === 'robots' ? robotsResult : sitemapResult;

  const handleCopy = () => {
    if (!currentResult) return;
    copyToClipboard(currentResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const switchGenerator = (type: GeneratorType) => {
    setActiveGenerator(type);
    setError(null);
    setIsLoading(false);
    setCopied(false);
  }

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">File Generator</h2>
      <p className="mb-6 text-brand-gray">Create `robots.txt` and `sitemap.xml` files with ease using AI.</p>
      
      <div className="flex border-b border-brand-gray mb-6">
        <button onClick={() => switchGenerator('robots')} className={`py-2 px-4 ${activeGenerator === 'robots' ? 'border-b-2 border-brand-blue text-white' : 'text-brand-gray'}`}>Robots.txt Generator</button>
        <button onClick={() => switchGenerator('sitemap')} className={`py-2 px-4 ${activeGenerator === 'sitemap' ? 'border-b-2 border-brand-blue text-white' : 'text-brand-gray'}`}>Sitemap.xml Generator</button>
      </div>

      <form onSubmit={handleGenerate}>
        {activeGenerator === 'robots' ? (
            <div>
                <label htmlFor="robotsInstruction" className="block text-sm font-medium mb-1">Instructions</label>
                <textarea
                    id="robotsInstruction"
                    value={robotsInstruction}
                    onChange={(e) => setRobotsInstruction(e.target.value)}
                    placeholder="e.g., Block the /admin directory. Allow everything else."
                    rows={4}
                    className="w-full p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
                />
            </div>
        ) : (
            <div>
                <label htmlFor="sitemapUrls" className="block text-sm font-medium mb-1">URLs (one per line)</label>
                <textarea
                    id="sitemapUrls"
                    value={sitemapUrls}
                    onChange={(e) => setSitemapUrls(e.target.value)}
                    placeholder="https://www.yourwebsite.com/page-1&#10;https://www.yourwebsite.com/page-2"
                    rows={6}
                    className="w-full p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
                />
            </div>
        )}
        <button
          type="submit"
          disabled={isLoading}
          className="mt-4 bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Generating...' : 'Generate File'}
        </button>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {currentResult && (
        <div className="mt-8 bg-brand-dark-light p-4 rounded-lg shadow-lg animate-fade-in">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold text-lg">Generated {activeGenerator === 'robots' ? 'robots.txt' : 'sitemap.xml'}</h3>
            <button onClick={handleCopy} className="bg-brand-gray/30 hover:bg-brand-gray/50 text-white text-sm font-bold py-2 px-4 rounded-md transition-colors">
              {copied ? 'Copied!' : 'Copy to Clipboard'}
            </button>
          </div>
          <pre className="bg-brand-dark p-4 rounded-md overflow-x-auto">
            <code className="text-white whitespace-pre-wrap">{currentResult}</code>
          </pre>
        </div>
      )}
    </div>
  );
};

export default FileGenerator;
