
import React, { useState, useEffect } from 'react';

declare global {
  const google: any;
}

interface AuthModalProps {
  mode: 'login' | 'signup';
  onClose: () => void;
  onLogin: (email: string, pass: string) => Promise<void>;
  onSignup: (email: string, pass: string) => Promise<void>;
  onGoogleSignIn: (response: any) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ mode, onClose, onLogin, onSignup, onGoogleSignIn }) => {
  const [currentMode, setCurrentMode] = useState(mode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const isGoogleSignInConfigured = !!process.env.GOOGLE_CLIENT_ID;

  useEffect(() => {
    if (!isGoogleSignInConfigured) {
      console.warn("GOOGLE_CLIENT_ID environment variable not set. Google Sign-In feature is disabled.");
      return;
    }

    const googleButtonContainer = document.getElementById('google-signin-button');

    if (typeof google !== 'undefined' && google.accounts) {
      google.accounts.id.initialize({
        client_id: process.env.GOOGLE_CLIENT_ID,
        callback: onGoogleSignIn
      });
      
      if (googleButtonContainer) {
        google.accounts.id.renderButton(
          googleButtonContainer,
          { theme: 'outline', size: 'large', width: '320' }
        );
      }
    } else {
      console.warn("Google Identity Services library not loaded yet.");
    }
  }, [isGoogleSignInConfigured, onGoogleSignIn]);

  const isLogin = currentMode === 'login';
  const title = isLogin ? 'Log In' : 'Sign Up';
  const buttonText = isLogin ? 'Log In' : 'Create Account';
  const switchText = isLogin ? "Don't have an account?" : "Already have an account?";
  const switchLinkText = isLogin ? "Sign Up" : "Log In";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      if (isLogin) {
        await onLogin(email, password);
      } else {
        await onSignup(email, password);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const switchMode = () => {
    setCurrentMode(isLogin ? 'signup' : 'login');
    setError(null);
    setEmail('');
    setPassword('');
  };

  return (
    <div 
      className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center animate-fade-in" 
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-brand-dark-light rounded-lg shadow-xl w-full max-w-md m-4 p-8 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-brand-gray hover:text-white"
          aria-label="Close authentication modal"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="text-3xl font-bold text-white text-center mb-6">{title}</h2>
        
        {isGoogleSignInConfigured && (
          <>
            <div id="google-signin-button" className="flex justify-center mb-4"></div>
            
            <div className="flex items-center my-4">
                <div className="flex-grow border-t border-brand-gray"></div>
                <span className="flex-shrink mx-4 text-brand-gray text-sm">OR</span>
                <div className="flex-grow border-t border-brand-gray"></div>
            </div>
          </>
        )}

        {error && <div className="mb-4 p-3 bg-red-900/50 border border-red-500 text-red-300 rounded-md text-center">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium mb-1 text-brand-light">Email Address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-3 bg-brand-dark border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="password"className="block text-sm font-medium mb-1 text-brand-light">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full p-3 bg-brand-dark border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex justify-center items-center bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : buttonText}
          </button>
        </form>

        <p className="text-center text-brand-gray mt-6">
          {switchText}
          <button onClick={switchMode} className="font-semibold text-brand-blue-light hover:underline ml-2">
            {switchLinkText}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthModal;
