import React, { useState, useEffect } from 'react';
import { calculateKeywordDensity, suggestRelatedKeywords } from '../services/geminiService';
import { KeywordDensityResult, Tool } from '../types';
import { renderSpinner, renderError, copyToClipboard } from '../utils/uiHelpers';
import DownloadControls from './DownloadControls';
import { getStringState, saveStringState, getState, saveState } from '../services/toolStateService';

const KeywordDensityChecker: React.FC = () => {
  const [text, setText] = useState(() => getStringState('keywordDensityChecker_text', ''));
  const [results, setResults] = useState<KeywordDensityResult[] | null>(() => getState('keywordDensityChecker_results', null));
  const [relatedKeywords, setRelatedKeywords] = useState<string[] | null>(() => getState('keywordDensityChecker_relatedKeywords', null));
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const reportId = 'keyword-density-report';

  useEffect(() => {
    saveStringState('keywordDensityChecker_text', text);
  }, [text]);

  useEffect(() => {
    saveState('keywordDensityChecker_results', results);
  }, [results]);

  useEffect(() => {
    saveState('keywordDensityChecker_relatedKeywords', relatedKeywords);
  }, [relatedKeywords]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim().split(/\s+/).length < 10) {
      setError('Please provide at least 10 words of text for an accurate analysis.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResults(null);
    setRelatedKeywords(null);
    setCopied(false);
    try {
      const [densityResults, suggestedKeywords] = await Promise.all([
        calculateKeywordDensity(text),
        suggestRelatedKeywords(text)
      ]);
      setResults(densityResults);
      setRelatedKeywords(suggestedKeywords);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyKeywords = () => {
    if (!relatedKeywords || relatedKeywords.length === 0) return;
    copyToClipboard(relatedKeywords.join(', '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">AI Keyword Density Checker</h2>
      <p className="mb-6 text-brand-gray">Paste your content below to analyze its keyword density and discover related keywords.</p>
      
      <form onSubmit={handleAnalyze} className="mb-8">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste your article text here..."
          rows={10}
          className="w-full p-3 bg-brand-dark-light border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
          aria-label="Text content for keyword density analysis"
        ></textarea>
        <button
          type="submit"
          disabled={isLoading}
          className="mt-4 bg-brand-blue hover:bg-brand-blue-light text-white font-bold py-3 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Analyzing...' : 'Analyze Text'}
        </button>
      </form>

      {isLoading && renderSpinner()}
      {error && renderError(error)}

      {(results || relatedKeywords) && (
        <div className="animate-fade-in">
            <div id={reportId} className="bg-brand-dark-light p-6 rounded-lg shadow-lg">
            {results && (
                <>
                <h3 className="font-semibold text-xl mb-4">Analysis Results</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                    <thead>
                        <tr className="border-b border-brand-gray">
                        <th className="p-3">Keyword/Phrase</th>
                        <th className="p-3 text-center">Count</th>
                        <th className="p-3 text-right">Density</th>
                        </tr>
                    </thead>
                    <tbody>
                        {results.map((result) => (
                        <tr key={result.keyword} className="border-b border-brand-gray/30">
                            <td className="p-3 font-medium">{result.keyword}</td>
                            <td className="p-3 text-center">{result.count}</td>
                            <td className="p-3 text-right font-mono">{result.density}</td>
                        </tr>
                        ))}
                    </tbody>
                    </table>
                </div>
                </>
            )}

            {relatedKeywords && relatedKeywords.length > 0 && (
                <div className="mt-8">
                    <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-xl">AI-Suggested Related Keywords</h3>
                    <button
                        onClick={handleCopyKeywords}
                        disabled={copied}
                        className="bg-brand-gray/30 hover:bg-brand-gray/50 text-white text-sm font-bold py-2 px-4 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {copied ? 'Copied!' : 'Copy All'}
                    </button>
                    </div>
                    <div className="flex flex-wrap gap-3">
                        {relatedKeywords.map((keyword) => (
                            <span key={keyword} className="bg-brand-blue/20 text-brand-blue-light text-sm font-medium px-3 py-1.5 rounded-full">
                                {keyword}
                            </span>
                        ))}
                    </div>
                </div>
            )}
            </div>
            <DownloadControls data={{ density: results, related: relatedKeywords }} toolName={Tool.KEYWORD_DENSITY} reportElementId={reportId} />
        </div>
      )}
    </div>
  );
};

export default KeywordDensityChecker;
