import React, { useState, useEffect } from 'react';
import { getStringState, saveStringState } from '../services/toolStateService';

const CharacterCountIndicator: React.FC<{ count: number; limit: number; warnAt: number }> = ({ count, limit, warnAt }) => {
  const percentage = Math.min((count / limit) * 100, 100);
  
  let barColor = 'bg-brand-blue-light';
  let textColor = 'text-brand-gray';

  if (count > limit) {
    barColor = 'bg-red-500';
    textColor = 'text-red-400 font-semibold';
  } else if (count > warnAt) {
    barColor = 'bg-yellow-400';
    textColor = 'text-yellow-300';
  }

  return (
    <div className="mt-2">
      <div className="flex justify-between items-center text-sm mb-1">
        <span className={textColor}>{count} / {limit} characters</span>
        {count > limit && <span className="text-red-400 font-semibold">Too long</span>}
      </div>
      <div className="w-full bg-brand-dark rounded-full h-1.5" role="presentation">
        <div 
          className={`h-1.5 rounded-full transition-all duration-300 ${barColor}`} 
          style={{ width: `${percentage}%` }}
          role="progressbar"
          aria-valuenow={count}
          aria-valuemin={0}
          aria-valuemax={limit}
          aria-label={`${count} of ${limit} characters used`}
        ></div>
      </div>
    </div>
  );
};


const SerpPreview: React.FC = () => {
  const [title, setTitle] = useState(() => getStringState('serpPreview_title', 'Example Title | Your Brand Name'));
  const [url, setUrl] = useState(() => getStringState('serpPreview_url', 'https://www.yourwebsite.com/example-page'));
  const [description, setDescription] = useState(() => getStringState('serpPreview_description', 'This is an example of a meta description. It should be compelling and concise to encourage clicks from the search results page.'));
  const [urlError, setUrlError] = useState<string | null>(null);

  useEffect(() => {
    saveStringState('serpPreview_title', title);
  }, [title]);

  useEffect(() => {
    saveStringState('serpPreview_url', url);
  }, [url]);

  useEffect(() => {
    saveStringState('serpPreview_description', description);
  }, [description]);

  const getUrlParts = (fullUrl: string) => {
    try {
        const urlObj = new URL(fullUrl);
        const domain = urlObj.hostname;
        const path = urlObj.pathname.replace(/^\/|\/$/g, '').replace(/\//g, ' › ');
        return { domain, path };
    } catch (e) {
        return { domain: 'yourwebsite.com', path: 'example › page' };
    }
  };

  const { domain, path } = getUrlParts(url);

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newUrl = e.target.value;
    setUrl(newUrl);

    if (newUrl.trim() && !newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
        setUrlError('URL must start with http:// or https://');
    } else {
        setUrlError(null);
    }
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold mb-2 text-white">SERP Snippet Preview</h2>
      <p className="mb-6 text-brand-gray">See how your webpage will appear in Google's search results. Optimize your title and description for maximum click-through rate.</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="bg-brand-dark-light p-6 rounded-lg">
          <div className="mb-4">
            <label htmlFor="title" className="block text-sm font-medium mb-1">Title</label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 bg-brand-dark border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            />
             <CharacterCountIndicator count={title.length} limit={60} warnAt={55} />
          </div>
          <div className="mb-4">
            <label htmlFor="url" className="block text-sm font-medium mb-1">URL</label>
            <input
              id="url"
              type="text"
              value={url}
              onChange={handleUrlChange}
              className={`w-full p-2 bg-brand-dark border rounded-md focus:ring-2 focus:outline-none transition-colors ${urlError ? 'border-red-500 focus:ring-red-500' : 'border-brand-gray focus:ring-brand-blue'}`}
              aria-invalid={!!urlError}
              aria-describedby={urlError ? 'url-error' : undefined}
            />
            {urlError && <p id="url-error" className="text-red-400 text-sm mt-1">{urlError}</p>}
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium mb-1">Description</label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              className="w-full p-2 bg-brand-dark border border-brand-gray rounded-md focus:ring-2 focus:ring-brand-blue focus:outline-none"
            ></textarea>
            <CharacterCountIndicator count={description.length} limit={160} warnAt={150} />
          </div>
        </div>

        {/* Live Preview */}
        <div className="bg-white p-4 rounded-lg text-black">
          <div className="font-sans">
            <div className="flex items-center mb-1">
                <span className="text-sm text-gray-800">{domain}</span>
                {path && <span className="text-sm text-gray-500 mx-1">›</span>}
                <span className="text-sm text-gray-500">{path}</span>
            </div>
            <h3 className="text-xl text-[#1a0dab] hover:underline cursor-pointer truncate">
                {title || 'Example Title | Your Brand Name'}
            </h3>
            <p className="text-sm text-gray-700 mt-1">
                {description || 'This is an example of a meta description...'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SerpPreview;
