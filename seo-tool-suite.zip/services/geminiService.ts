import { GoogleGenAI, Type } from "@google/genai";
import type { 
    KeywordDensityResult, 
    CompetitorAnalysisResult, 
    BacklinkResult, 
    OnPageAnalysisResult, 
    LighthouseReportResult,
    ContentGapResult,
    PaaResult,
    SearchIntentResult,
    ContentBriefResult
} from "../types";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Extracts a JSON object or array from a string that might contain extraneous text.
 * @param responseText The text response from the AI.
 * @returns The parsed JSON object.
 */
function extractAndParseJson<T>(responseText: string): T {
    const trimmedResponse = responseText.trim();
    
    // Attempt to find a JSON object or array within the string using a regular expression
    const jsonRegex = /({.*}|\[.*\])/s; // 's' flag allows '.' to match newlines
    const match = trimmedResponse.match(jsonRegex);

    if (!match) {
        console.error("Could not find a valid JSON object or array in the AI's response.", trimmedResponse);
        throw new Error("The AI response did not contain a valid JSON structure.");
    }

    const jsonString = match[0];

    try {
        return JSON.parse(jsonString) as T;
    } catch (e) {
        console.error("Failed to parse JSON from AI response:", e);
        console.error("Raw response text:", responseText);
        console.error("Extracted string for parsing:", jsonString);
        throw new Error("The AI returned a malformed response. Please try again.");
    }
}


interface MetaTags {
  title: string;
  description: string;
  keywords: string[];
}

export const generateMetaTags = async (topic: string): Promise<MetaTags> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate SEO-optimized meta tags for a webpage about '${topic}'. Provide a title (max 60 characters), a meta description (max 160 characters), and 5-7 relevant keywords.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: "SEO-optimized title, max 60 characters."
            },
            description: {
              type: Type.STRING,
              description: "SEO-optimized meta description, max 160 characters."
            },
            keywords: {
              type: Type.ARRAY,
              description: "An array of 5-7 relevant keywords.",
              items: {
                type: Type.STRING
              }
            }
          },
          required: ["title", "description", "keywords"]
        }
      }
    });

    if (!response.text) {
        throw new Error("Received empty response from API");
    }

    return extractAndParseJson<MetaTags>(response.text);

  } catch (error) {
    console.error("Error generating meta tags:", error);
    throw new Error("Failed to generate meta tags with AI. Please try again.");
  }
};

export const calculateKeywordDensity = async (text: string): Promise<KeywordDensityResult[]> => {
  if (text.trim().split(/\s+/).length < 10) {
      throw new Error("Please provide at least 10 words of text for an accurate analysis.");
  }
  try {
    const analysisResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze the following text and calculate the keyword density for the most frequent 1, 2, and 3-word phrases. Return the top 10 results as a clear text list. The text is: "${text}"`,
    });

    const analysisText = analysisResponse.text;
    if (!analysisText) {
        throw new Error("Received empty analysis from the initial phase.");
    }
    
    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following keyword density analysis, structure the information into a JSON object. The text is: "${analysisText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    keywords: {
                        type: Type.ARRAY,
                        description: "An array of keyword density results.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                keyword: {
                                    type: Type.STRING,
                                    description: "The keyword or phrase."
                                },
                                count: {
                                    type: Type.INTEGER,
                                    description: "How many times the keyword appears."
                                },
                                density: {
                                    type: Type.STRING,
                                    description: "The keyword density as a percentage string (e.g., '1.5%')."
                                }
                            },
                            required: ["keyword", "count", "density"]
                        }
                    }
                },
                required: ["keywords"]
            }
        }
    });

    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }

    const parsedResponse = extractAndParseJson<{ keywords: KeywordDensityResult[] }>(structuringResponse.text);
    return parsedResponse.keywords;

  } catch (error) {
    console.error("Error calculating keyword density:", error);
    throw new Error("Failed to calculate keyword density with AI. Please try again.");
  }
};

export const suggestRelatedKeywords = async (text: string): Promise<string[]> => {
  try {
    const analysisResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the following text, suggest a list of 10-15 related keywords and LSI (Latent Semantic Indexing) keywords that could improve its SEO. Focus on semantic relevance and user intent. Return a simple comma-separated list. The text is: "${text}"`,
    });
    
    const keywordsText = analysisResponse.text;
    if (!keywordsText) {
        throw new Error("Received empty response from AI when suggesting keywords.");
    }
    
    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following text containing a list of keywords, please structure them into a JSON object. The text is: "${keywordsText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    keywords: {
                        type: Type.ARRAY,
                        description: "An array of 10-15 related and LSI keywords.",
                        items: {
                            type: Type.STRING
                        }
                    }
                },
                required: ["keywords"]
            }
        }
    });

    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }

    const parsedResponse = extractAndParseJson<{ keywords: string[] }>(structuringResponse.text);
    return parsedResponse.keywords;

  } catch (error) {
    console.error("Error suggesting related keywords:", error);
    throw new Error("Failed to suggest related keywords with AI. Please try again.");
  }
};

export const generateRobotsTxt = async (rules: { instruction: string }): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a robots.txt file based on the following instruction: "${rules.instruction}". For example, "Allow all bots except for Google's ads bot. Disallow access to the /admin and /private folders." Ensure the output is only the valid robots.txt content and nothing else.`,
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating robots.txt:", error);
        throw new Error("Failed to generate robots.txt with AI. Please try again.");
    }
};

export const generateSitemap = async (urls: string[]): Promise<string> => {
    if (urls.length === 0) {
        throw new Error("Please provide at least one URL.");
    }
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a valid sitemap.xml file containing the following URLs: ${urls.join(', ')}. Ensure the output is only the valid XML content and nothing else. Use a lastmod date of today, a changefreq of 'daily', and a priority of '0.8'.`,
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error generating sitemap:", error);
        throw new Error("Failed to generate sitemap.xml with AI. Please try again.");
    }
};

export const analyzeCompetitorUrl = async (url: string): Promise<CompetitorAnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `As an expert SEO analyst, perform a competitive analysis of the website at the URL: ${url}. Based on publicly available information from Google Search, provide an estimated Domain Authority (DA), estimated monthly traffic, and approximate backlink count. Also, provide a summary, identify its main keywords, describe its likely content strategy, and list its potential SEO strengths and weaknesses.`,
      config: {
        tools: [{googleSearch: {}}],
      },
    });

    const analysisText = response.text;
    if (!analysisText) {
        throw new Error("Received empty analysis from the initial search.");
    }

    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following SEO analysis text, please structure the information into a JSON object. The text is: "${analysisText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    domainAuthority: {
                        type: Type.STRING,
                        description: "Estimated Domain Authority (DA) score, e.g., '85' or 'N/A'."
                    },
                    estimatedMonthlyTraffic: {
                        type: Type.STRING,
                        description: "Estimated monthly organic traffic, e.g., '1.2M' or '10k-25k'."
                    },
                    backlinkCount: {
                        type: Type.STRING,
                        description: "Approximate number of backlinks, e.g., '250,000'."
                    },
                    summary: {
                        type: Type.STRING,
                        description: "A brief summary of the website's SEO profile."
                    },
                    mainKeywords: {
                        type: Type.ARRAY,
                        description: "A list of the primary keywords the site appears to target.",
                        items: { type: Type.STRING }
                    },
                    contentStrategy: {
                        type: Type.STRING,
                        description: "An overview of the website's content strategy."
                    },
                    seoStrengths: {
                        type: Type.ARRAY,
                        description: "A list of the website's SEO strengths.",
                        items: { type: Type.STRING }
                    },
                    seoWeaknesses: {
                        type: Type.ARRAY,
                        description: "A list of the website's potential SEO weaknesses.",
                        items: { type: Type.STRING }
                    }
                },
                required: ["domainAuthority", "estimatedMonthlyTraffic", "backlinkCount", "summary", "mainKeywords", "contentStrategy", "seoStrengths", "seoWeaknesses"]
            }
        }
    });

    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }

    return extractAndParseJson<CompetitorAnalysisResult>(structuringResponse.text);

  } catch (error) {
    console.error("Error analyzing competitor URL:", error);
    throw new Error("Failed to analyze the competitor URL with AI. Please try again or check the URL.");
  }
};

export const findBacklinks = async (domain: string): Promise<BacklinkResult[]> => {
  try {
    const searchResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Using Google Search, act as an SEO expert to find the top 10 most authoritative backlinks pointing to the domain ${domain}. For each backlink, provide the full source URL, the exact anchor text used, and an estimated Domain Authority (on a scale of 0-100) of the linking domain.`,
      config: {
        tools: [{googleSearch: {}}],
      },
    });

    const backlinkText = searchResponse.text;
    if (!backlinkText) {
        throw new Error("Received empty backlink data from the initial search.");
    }

    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following backlink analysis text, please structure the information into a JSON object. The text is: "${backlinkText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    backlinks: {
                        type: Type.ARRAY,
                        description: "An array of backlink results.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                sourceUrl: {
                                    type: Type.STRING,
                                    description: "The full URL of the page containing the backlink."
                                },
                                anchorText: {
                                    type: Type.STRING,
                                    description: "The anchor text of the hyperlink."
                                },
                                sourceDomainAuthority: {
                                    type: Type.STRING,
                                    description: "The estimated Domain Authority (DA) of the source domain, e.g., '85'."
                                }
                            },
                             required: ["sourceUrl", "anchorText", "sourceDomainAuthority"]
                        }
                    }
                },
                required: ["backlinks"]
            }
        }
    });

    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }
    
    const parsed = extractAndParseJson<{ backlinks: BacklinkResult[] }>(structuringResponse.text);
    return parsed.backlinks;

  } catch (error) {
    console.error("Error finding backlinks:", error);
    throw new Error("Failed to find backlinks with AI. Please try again or check the domain.");
  }
};

export const analyzeOnPageSeo = async (url: string): Promise<OnPageAnalysisResult> => {
  try {
    const analysisResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `As an expert SEO analyst, use Google Search to analyze the on-page SEO elements of the URL: ${url}. Based on information available in the search index, extract the following: 1. All H1, H2, and H3 headings. 2. Key images with their 'src' and 'alt' text (if alt is missing, state that). 3. A list of internal and external links with their anchor text and 'href'. Present the findings as a clear text summary.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const analysisText = analysisResponse.text;
    if (!analysisText) {
      throw new Error("Received empty analysis from the initial search.");
    }
    
    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following on-page SEO analysis text, please structure the information into a JSON object. Ensure all fields are populated correctly. The text is: "${analysisText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    headings: {
                        type: Type.OBJECT,
                        properties: {
                            h1: { type: Type.ARRAY, items: { type: Type.STRING } },
                            h2: { type: Type.ARRAY, items: { type: Type.STRING } },
                            h3: { type: Type.ARRAY, items: { type: Type.STRING } },
                        },
                        required: ["h1", "h2", "h3"]
                    },
                    images: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                src: { type: Type.STRING },
                                alt: { type: Type.STRING, description: "The alt text. If missing, this should be an empty string or 'Missing'." }
                            },
                            required: ["src", "alt"]
                        }
                    },
                    links: {
                        type: Type.OBJECT,
                        properties: {
                            internal: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        text: { type: Type.STRING },
                                        href: { type: Type.STRING }
                                    },
                                    required: ["text", "href"]
                                }
                            },
                            external: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        text: { type: Type.STRING },
                                        href: { type: Type.STRING }
                                    },
                                    required: ["text", "href"]
                                }
                            }
                        },
                        required: ["internal", "external"]
                    }
                },
                required: ["headings", "images", "links"]
            }
        }
    });
    
    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }

    return extractAndParseJson<OnPageAnalysisResult>(structuringResponse.text);

  } catch (error) {
    console.error("Error analyzing on-page SEO:", error);
    throw new Error("Failed to analyze the page with AI. Please try again or check the URL.");
  }
};

export const generateLighthouseReport = async (url: string): Promise<LighthouseReportResult> => {
  try {
    const analysisResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Act as an expert SEO analyst performing a Google Lighthouse/GTmetrix style audit on the URL: ${url}. Use Google Search to analyze the page's content and structure.
      Provide an estimated score (0-100) for each of the four main Lighthouse categories: Performance, Accessibility, Best Practices, and SEO.
      For EACH of these four categories, provide a detailed list of:
      1. 'passed' audits: Key items the page is doing well.
      2. 'improvements': The most important areas for improvement with actionable advice.
      For the Performance category improvements, please include specific metrics like Largest Contentful Paint (LCP), Total Blocking Time (TBT), and Cumulative Layout Shift (CLS) if possible.
      Structure the entire output according to the provided JSON schema.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const analysisText = analysisResponse.text;
    if (!analysisText) {
      throw new Error("Received empty analysis from the initial search.");
    }
    
    const auditItemSchema = {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING, description: "The title of the audit (e.g., 'Has a <title> element')." },
            description: { type: Type.STRING, description: "A brief description of the audit result." }
        },
        required: ["title", "description"]
    };

    const categorySchema = {
        type: Type.OBJECT,
        properties: {
            passed: { type: Type.ARRAY, items: auditItemSchema },
            improvements: { type: Type.ARRAY, items: auditItemSchema }
        },
        required: ["passed", "improvements"]
    };

    const structuringResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the following Lighthouse-style SEO analysis, structure the information into a JSON object. The text is: "${analysisText}"`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    scores: {
                        type: Type.OBJECT,
                        properties: {
                            performance: { type: Type.INTEGER, description: "Score from 0-100 for Performance." },
                            accessibility: { type: Type.INTEGER, description: "Score from 0-100 for Accessibility." },
                            bestPractices: { type: Type.INTEGER, description: "Score from 0-100 for Best Practices." },
                            seo: { type: Type.INTEGER, description: "Score from 0-100 for SEO." }
                        },
                        required: ["performance", "accessibility", "bestPractices", "seo"]
                    },
                    audits: {
                        type: Type.OBJECT,
                        properties: {
                            performance: categorySchema,
                            accessibility: categorySchema,
                            bestPractices: categorySchema,
                            seo: categorySchema,
                        },
                        required: ["performance", "accessibility", "bestPractices", "seo"]
                    }
                },
                required: ["scores", "audits"]
            }
        }
    });

    if (!structuringResponse.text) {
        throw new Error("Received empty response from API during structuring phase.");
    }

    return extractAndParseJson<LighthouseReportResult>(structuringResponse.text);

  } catch (error) {
    console.error("Error generating Lighthouse report:", error);
    throw new Error("Failed to generate Lighthouse report with AI. Please try again or check the URL.");
  }
};


export const analyzeContentGap = async (userUrl: string, competitorUrl: string): Promise<ContentGapResult> => {
    try {
        // Step 1: Get keywords for the user's URL
        const userKeywordsResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Using Google Search, identify the main SEO keywords and topics for the URL: ${userUrl}`,
            config: { tools: [{ googleSearch: {} }] }
        });
        const userKeywordsText = userKeywordsResponse.text;

        // Step 2: Get keywords for the competitor's URL
        const competitorKeywordsResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Using Google Search, identify the main SEO keywords and topics for the URL: ${competitorUrl}`,
            config: { tools: [{ googleSearch: {} }] }
        });
        const competitorKeywordsText = competitorKeywordsResponse.text;

        if (!userKeywordsText || !competitorKeywordsText) {
            throw new Error("Could not retrieve keyword data for one or both URLs.");
        }

        // Step 3: Compare the two sets of keywords and structure the output
        const structuringResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Here are two lists of keywords and topics.
            List A (for my site): "${userKeywordsText}"
            List B (for my competitor's site): "${competitorKeywordsText}"
            
            Identify and return a list of important keywords from List B that are NOT present or well-covered in List A. These are the "gap keywords".`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        gapKeywords: {
                            type: Type.ARRAY,
                            description: "An array of keywords the competitor ranks for but the user's URL does not.",
                            items: { type: Type.STRING }
                        }
                    },
                    required: ["gapKeywords"]
                }
            }
        });

        if (!structuringResponse.text) {
            throw new Error("Received empty response from API during structuring phase.");
        }
        return extractAndParseJson<ContentGapResult>(structuringResponse.text);
    } catch (error) {
        console.error("Error analyzing content gap:", error);
        throw new Error("Failed to analyze content gap. Please check the URLs and try again.");
    }
};

export const extractPeopleAlsoAsk = async (topic: string): Promise<PaaResult> => {
    try {
        const searchResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Using Google Search, find the 'People Also Ask' (PAA) questions related to the topic: "${topic}". Return a list of the most relevant questions.`,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });
        
        const paaText = searchResponse.text;
        if (!paaText) {
            throw new Error("Received empty response from API during search phase.");
        }
        
        const structuringResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following text containing 'People Also Ask' questions, extract the questions and structure them into a JSON object. The text is: "${paaText}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        questions: {
                            type: Type.ARRAY,
                            description: "An array of 'People Also Ask' questions.",
                            items: { type: Type.STRING }
                        }
                    },
                    required: ["questions"]
                }
            }
        });

        if (!structuringResponse.text) {
            throw new Error("Received empty response from API during structuring phase.");
        }
        return extractAndParseJson<PaaResult>(structuringResponse.text);
    } catch (error) {
        console.error("Error extracting People Also Ask:", error);
        throw new Error("Failed to extract PAA questions. Please try again.");
    }
};

export const classifySearchIntent = async (keywords: string[]): Promise<SearchIntentResult[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `For each keyword provided, classify its primary search intent as 'Informational', 'Navigational', 'Commercial', or 'Transactional'. Provide a brief one-sentence explanation for each classification. The keywords are: ${keywords.join(', ')}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        classifications: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    keyword: { type: Type.STRING },
                                    intent: { type: Type.STRING, description: "Can be Informational, Navigational, Commercial, or Transactional." },
                                    explanation: { type: Type.STRING }
                                },
                                required: ["keyword", "intent", "explanation"]
                            }
                        }
                    },
                    required: ["classifications"]
                }
            }
        });
        if (!response.text) {
            throw new Error("Received empty response from API.");
        }
        const parsed = extractAndParseJson<{ classifications: SearchIntentResult[] }>(response.text);
        return parsed.classifications;
    } catch (error) {
        console.error("Error classifying search intent:", error);
        throw new Error("Failed to classify keyword intent. Please try again.");
    }
};


export const generateContentBrief = async (topic: string): Promise<ContentBriefResult> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Create a comprehensive SEO content brief for an article about the topic: "${topic}". 
            The brief should include all of the following sections:
            1. A compelling, SEO-optimized title.
            2. A description of the target audience.
            3. A detailed content outline with H2 and H3 headings.
            4. A list of 10-15 related and LSI keywords to include.
            5. A suggested word count range (e.g., '1500-2000 words').
            6. Three internal link suggestions with appropriate anchor text and placeholder URLs (e.g., '/blog/related-topic').`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        targetAudience: { type: Type.STRING },
                        outline: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    heading: { type: Type.STRING, description: "The H2 or H3 heading text." },
                                    subheadings: {
                                        type: Type.ARRAY,
                                        items: { type: Type.STRING },
                                        description: "An array of sub-heading texts under the main heading."
                                    }
                                },
                                required: ["heading", "subheadings"]
                            }
                        },
                        relatedKeywords: {
                            type: Type.ARRAY,
                            items: { type: Type.STRING }
                        },
                        wordCount: { type: Type.STRING },
                        internalLinkSuggestions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    anchorText: { type: Type.STRING },
                                    suggestedUrl: { type: Type.STRING }
                                },
                                required: ["anchorText", "suggestedUrl"]
                            }
                        }
                    },
                    required: ["title", "targetAudience", "outline", "relatedKeywords", "wordCount", "internalLinkSuggestions"]
                }
            }
        });

        if (!response.text) {
            throw new Error("Received empty response from API.");
        }
        return extractAndParseJson<ContentBriefResult>(response.text);

    } catch (error) {
        console.error("Error generating content brief:", error);
        throw new Error("Failed to generate content brief. Please try again.");
    }
};