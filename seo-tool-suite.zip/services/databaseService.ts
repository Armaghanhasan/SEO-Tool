import { User, Tool } from '../types';
import { ADMIN_EMAIL, ADMIN_PASSWORD } from '../config';

const USER_PREFIX = 'user_';
const SESSION_KEY = 'seo_tool_user';

// --- Security Warning ---
/**
 * Encodes a password using Base64.
 * WARNING: This is NOT a secure method for storing passwords. It is easily reversible.
 * This is for demonstration purposes in a client-only application.
 * A production application MUST use a secure backend with proper hashing algorithms (e.g., bcrypt).
 * @param pass The password string.
 * @returns The Base64 encoded password.
 */
const encodePassword = (pass: string): string => btoa(pass);

/**
 * Decodes a Base64 password string.
 * @param encodedPass The Base64 encoded password.
 * @returns The original password string.
 */
const decodePassword = (encodedPass: string): string => atob(encodedPass);
// --- End Security Warning ---

// --- User Management ---

interface StoredUserData extends User {
  password?: string;
  isGoogleAccount?: boolean;
}

/**
 * Retrieves a user's full data, including password field, from localStorage.
 * @param email The user's email.
 * @returns The user data object or null if not found.
 */
const getStoredUser = (email: string): StoredUserData | null => {
  const data = localStorage.getItem(`${USER_PREFIX}${email}`);
  return data ? JSON.parse(data) : null;
};

/**
 * Saves a user's full data to localStorage.
 * @param data The user data to save.
 */
const saveStoredUser = (data: StoredUserData): void => {
  localStorage.setItem(`${USER_PREFIX}${data.email}`, JSON.stringify(data));
};

/**
 * Retrieves a user by email.
 * @param email The user's email.
 * @returns A promise resolving to the user object or null.
 */
export const getUser = async (email: string): Promise<User | null> => {
  const storedUser = getStoredUser(email);
  if (!storedUser) return null;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { password, ...user } = storedUser;
  return user;
};

/**
 * Gets all users from localStorage.
 * @returns An array of all users.
 */
export const getAllUsers = (): User[] => {
  const users: User[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith(USER_PREFIX)) {
      try {
        const storedData = JSON.parse(localStorage.getItem(key) as string) as StoredUserData;
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password, ...user } = storedData;
        users.push(user);
      } catch (e) {
        console.error(`Failed to parse user data for key: ${key}`, e);
      }
    }
  }
  return users;
};

/**
 * Updates a user's data.
 * @param updatedUser The user object with updated fields.
 */
export const updateUser = (updatedUser: User): void => {
  const storedUser = getStoredUser(updatedUser.email) || {};
  const newUserData = { ...storedUser, ...updatedUser };
  saveStoredUser(newUserData);

  const currentUser = getCurrentUser();
  if (currentUser?.email === updatedUser.email) {
    setCurrentUser(updatedUser);
  }
};

/**
 * Deletes a user from storage.
 * @param email The email of the user to delete.
 */
export const deleteUser = (email: string): void => {
  localStorage.removeItem(`${USER_PREFIX}${email}`);
  const currentUser = getCurrentUser();
  if (currentUser?.email === email) {
    logout();
  }
};

// --- Authentication ---

/**
 * Attempts to sign up a new user.
 * @param email User's email.
 * @param pass User's password.
 * @returns A promise resolving to the new user object.
 */
export const signup = async (email: string, pass: string): Promise<User> => {
  if (getStoredUser(email)) {
    throw new Error('An account with this email already exists.');
  }
  const isAdmin = email === ADMIN_EMAIL;
  const user: User = { 
    email,
    role: isAdmin ? 'admin' : 'user',
    isApproved: isAdmin,
    approvedTools: isAdmin ? Object.values(Tool) : []
  };
  saveStoredUser({ ...user, password: encodePassword(pass) });
  setCurrentUser(user);
  return user;
};

/**
 * Attempts to log in a user.
 * @param email User's email.
 * @param pass User's password.
 * @returns A promise resolving to the user object.
 */
export const login = async (email: string, pass: string): Promise<User> => {
  const storedUser = getStoredUser(email);
  if (!storedUser || !storedUser.password || decodePassword(storedUser.password) !== pass) {
    throw new Error('Invalid email or password.');
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { password, ...user } = storedUser;
  setCurrentUser(user);
  return user;
};

/**
 * Simple JWT decoder
 */
 const decodeJwt = (token: string) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
      return null;
    }
  };

/**
 * Handles user creation/login from Google Sign-In.
 * @param credentialResponse The response object from Google.
 * @returns The user object for the app session.
 */
export const upsertUserFromGoogle = (credentialResponse: any): User => {
    const googleUser = decodeJwt(credentialResponse.credential);
    if (!googleUser) {
        throw new Error("Failed to decode JWT from Google response");
    }

    const isAdmin = googleUser.email === ADMIN_EMAIL;
    const existingUser = getStoredUser(googleUser.email);
    
    const user: User = {
        email: googleUser.email,
        name: googleUser.name,
        picture: googleUser.picture,
        role: isAdmin ? 'admin' : (existingUser?.role || 'user'),
        isApproved: isAdmin ? true : (existingUser?.isApproved || false),
        approvedTools: isAdmin ? Object.values(Tool) : (existingUser?.approvedTools || [])
    };
    
    saveStoredUser({ ...existingUser, ...user, isGoogleAccount: true });
    setCurrentUser(user);
    return user;
};

// --- Session Management ---

/**
 * Gets the currently logged-in user from the session.
 * @returns The current user or null.
 */
export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(SESSION_KEY);
  if (!userJson) return null;
  try {
    return JSON.parse(userJson) as User;
  } catch (error) {
    console.error("Failed to parse user from session", error);
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
};

/**
 * Sets the currently logged-in user in the session.
 * @param user The user to set as current.
 */
export const setCurrentUser = (user: User): void => {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
};

/**
 * Logs the current user out.
 */
export const logout = (): void => {
  localStorage.removeItem(SESSION_KEY);
};

// --- Initialization ---

/**
 * Ensures the admin user exists with the correct credentials and permissions.
 * To be called on application startup.
 */
export const initializeAdminUser = (): void => {
  const storedAdmin = getStoredUser(ADMIN_EMAIL) || {};
  const adminPassword = encodePassword(ADMIN_PASSWORD);
  
  const adminData: StoredUserData = {
    ...storedAdmin,
    email: ADMIN_EMAIL,
    role: 'admin',
    isApproved: true,
    approvedTools: Object.values(Tool),
    password: adminPassword,
  };

  saveStoredUser(adminData);
};
