/**
 * A service to manage persisting tool state (inputs, results) to localStorage.
 * This abstracts the persistence logic away from the UI components.
 */

/**
 * Retrieves a saved state value from localStorage.
 * @param key The unique key for the state.
 * @param defaultValue The value to return if nothing is found.
 * @returns The parsed state value or the default value.
 */
export const getState = <T>(key: string, defaultValue: T): T => {
    const saved = localStorage.getItem(key);
    if (saved === null) {
        return defaultValue;
    }
    try {
        // Assume all stored state is JSON
        return JSON.parse(saved) as T;
    } catch (e) {
        console.error(`Failed to parse state for key "${key}"`, e);
        // If parsing fails, it might be a raw string from a previous version.
        // Return it if the expected type is string.
        if (typeof defaultValue === 'string') {
          return saved as any;
        }
        return defaultValue;
    }
};

/**
 * Saves a state value to localStorage.
 * @param key The unique key for the state.
 * @param value The value to save. It will be JSON.stringified.
 */
export const saveState = <T>(key: string, value: T): void => {
    if (value === null || value === undefined) {
        localStorage.removeItem(key);
    } else {
        // Store everything as a JSON string for consistency
        localStorage.setItem(key, JSON.stringify(value));
    }
};

/**
 * A specialized version of getState for simple string values, for convenience.
 * @param key The unique key for the state.
 * @param defaultValue The default string value.
 * @returns The stored string or the default value.
 */
export const getStringState = (key: string, defaultValue: string): string => {
    const value = localStorage.getItem(key);
    if (value === null) return defaultValue;
    // Attempt to parse in case it was stored as a JSON string
    try {
        return JSON.parse(value);
    } catch {
        return value;
    }
}

/**
 * A specialized version of saveState for simple string values.
 * @param key The unique key for the state.
 * @param value The string value to save.
 */
export const saveStringState = (key: string, value: string): void => {
    // We still stringify to keep all storage operations consistent
    localStorage.setItem(key, JSON.stringify(value));
}
